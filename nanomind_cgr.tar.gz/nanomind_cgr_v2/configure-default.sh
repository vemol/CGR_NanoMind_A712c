./waf configure --config-sd-cs=3 --with-console=0 --hostname="nanomind" --model="a712B"
./waf clean build -p

