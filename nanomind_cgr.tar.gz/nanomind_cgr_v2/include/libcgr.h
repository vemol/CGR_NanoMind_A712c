


#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/time.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <limits.h>





#define CGRDEBUG 0
#define FALSE 0
#define TRUE 1
#define NO 0
#define YES 1
#define INF 5000000



typedef unsigned int node;

struct node_list {

	node nInL;
	struct node_list *next;

};

typedef struct node_list nodeList;

typedef struct prx_node{
	node node;
	time_t arrivalTime;
	unsigned int hopCount;
	char *id;
}prxnode;

struct prxnode_list {

	prxnode prxmNode;
	struct prxnode_list *next;

};

typedef struct prxnode_list prxnodeList;

 struct contact{
  	// parametros minimos para UN contacto ISL

  	node source;
  	node destination;
  	time_t start;
  	time_t end;
  	unsigned int rate;

  	//work area
	time_t arrivalTime;
	unsigned int capacity;
	unsigned int residualCapacity;
	unsigned int confidence;
	int visited;		//boolean
	int suppressed;
	struct contact *predecessor;	//para guardar el contacto anterior
	struct contact *sucessor;	//para guardar el contacto siguiente
	nodeList *visitedNodes;

	struct contact *next;
  	struct contact *prev;

  };

 typedef struct contact Contact;


 struct contactList{

	 Contact *contact;
	 struct contactList *prev;
	 struct contactList *next;

 };


struct routeStr{

	 Contact *ctcList;
	 node firstHop;
	 nodeList *hops;
	 unsigned int hopCount;
	 time_t toTime;
	 time_t arrivalTime;
	 unsigned int capacity;

 };


struct routeList{

	struct routeStr *route;
	struct routeList *prev;
	struct routeList *next;
};

 typedef struct {

	 char *data;
	 unsigned int bitlength;

	 time_t startTime;
	 time_t deadline;
	 node startnode;
	 node destination;	// no confundir destino de contacto con destino de bundle

	 // metricas para tomar futuras decisiones
	 int shortestPath;	//boolean
	 int lessEnergy;	//boolean
	 int returnToSender;
	 int critical;

 }Bundle;



 nodeList *addToNodeList(nodeList *, node);
 prxnodeList *addToPrxNodeList(prxnodeList *,prxnode);
 struct routeList *appendRoute(struct routeList *, struct routeStr *);

 void cgrForward(Bundle *bundle, Contact *cp, nodeList *En);
 struct routeList *cgrAllPathsAnchor(node, node, time_t, Contact *);
 void clearWorkAreas(Contact *);
 void clearWorkArea(Contact *);
 Bundle *create_bundle();
 struct contactList *createNeighborList(Contact *cp);
 struct routeStr *dijkstra(Contact *, node , Contact *);
 //void dijkstra(Contact *, node , Contact *);
 struct routeList *first_depleted(node, node, time_t , Contact *, int);

 unsigned int isInNodeList(nodeList *, node);
 unsigned int isInPrxNodeList(prxnodeList *, node);
 prxnodeList *identifyProximateNodes(Bundle *, Contact *, nodeList *);
 time_t min(time_t, time_t);
 Contact *nextContact(node, Contact *cp);
 //para determinar el proximo contacto del destino con la siguiente fuente
 //destino = siguiente fuente (la misma ruta pero siguiente salto)
 Contact *nextNeighbor(Contact *cp);
 //para determinar los contactos alternativos o vecinos
 //fuente de contacto = fuente del suiguiente contacto, (ruta alternativa)


 struct routeList *loadRouteList(Bundle *, Contact *);
 Contact *load_plan();
 void printRoute(struct routeStr *);
 void printRoutes(struct routeList *);
 void printCtc(Contact *);
 void printCp(Contact *);






