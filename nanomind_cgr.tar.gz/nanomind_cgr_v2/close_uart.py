#javier: escribe en uart
#curso@curso:~$ ls /dev/ttyUSB*


import serial

ser = serial.Serial('/dev/ttyUSB0', 500000)
ser.close()
 




 
