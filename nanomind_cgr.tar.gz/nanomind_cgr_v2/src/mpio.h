/**
 * IO header for NanoMind A712-D revision and onwards
 *
 * @author Johan De Claville Christiansen
 * Copyright 2012 GomSpace ApS. All rights reserved.
 */

#ifndef IO_H_
#define IO_H_

#include <dev/arm/at91sam7.h>

#define IO_PIN_47			1		// T0T1OA0
#define IO_PIN_48			2		// T0T1OB0
#define IO_PIN_49			3		// T0TCLK0
#define IO_PIN_50			4		// T0T1OA1
#define IO_PIN_51			5		// T0T1OB1
#define IO_PIN_52			6		// T0TCLK1
#define IO_PIN_53			7		// T0T1OA2

#define ENABLE_RTC			1
/**
 * Initialise IO pin
 * @param pin number
 * @param output 1 = set as output, 0 = set as input
 */
void io_init(int pin, int output);

/**
 * Read value of IO pin
 * @param pin number
 * @return value of IO pin
 */
int io_get(int pin);

/**
 * Set IO pin high
 * @param pin number
 */
void io_set(int pin);

/**
 * Set IO pin low
 * @param pin number
 */
void io_clear(int pin);

#endif /* IO_H_ */
