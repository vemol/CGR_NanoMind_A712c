/*
 * csp_console.h
 *
 *  Created on: 03/05/2010
 *      Author: oem
 */

#ifndef CSP_CONSOLE_H_
#define CSP_CONSOLE_H_

void csp_console_init(void);

#endif /* CSP_CONSOLE_H_ */
