/*
 * cmd_ftp.h
 *
 *  Created on: 07/07/2010
 *      Author: Johan
 */

#ifndef CMD_H_
#define CMD_H_

void cmd_ftp_setup(void);
void cmd_cam_setup(void);
void cmd_com_setup(int node_arg);
void cmd_obc_setup(void);
void cmd_eps_setup(void);
void cmd_hub_setup(void);

#endif /* CMD_H_ */
