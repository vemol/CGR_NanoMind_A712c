/*
 * sdram.h
 *
 *  Created on: Oct 5, 2009
 *      Author: Administrator
 */

#ifndef SDRAM_H_
#define SDRAM_H_

void sdram_init(unsigned int cas);
void sdram_set_timing(unsigned long hsb_hz, unsigned int cas);
void sdram_set_refresh_rate(unsigned long hsb_hz);
void sdram_test(void * start_addr, unsigned int length);

#endif /* SDRAM_H_ */
