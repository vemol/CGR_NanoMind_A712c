/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief FreeRTOS port source for AVR32 AP7000.
 *
 * - Compiler:           GNU GCC for AVR32
 * - Supported devices:  All AVR32AP700x devices can be used.
 * - AppNote:
 *
 * \author               Torsten Brischalle email: torsten@brischalle.de  \n
 *                       based on AVR32 UC3 port from Atmel Corporation:  \n
 *                       http://www.atmel.com
 *
 *****************************************************************************/

/*
    FreeRTOS.org V5.2.0 - Copyright (C) 2003-2009 Richard Barry.

    This file is part of the FreeRTOS.org distribution.

    FreeRTOS.org is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License (version 2) as published
    by the Free Software Foundation and modified by the FreeRTOS exception.

    FreeRTOS.org is distributed in the hope that it will be useful,	but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along
    with FreeRTOS.org; if not, write to the Free Software Foundation, Inc., 59
    Temple Place, Suite 330, Boston, MA  02111-1307  USA.

    A special exception to the GPL is included to allow you to distribute a
    combined work that includes FreeRTOS.org without being obliged to provide
    the source code for any proprietary components.  See the licensing section
    of http://www.FreeRTOS.org for full details.


    ***************************************************************************
    *                                                                         *
    * Get the FreeRTOS eBook!  See http://www.FreeRTOS.org/Documentation      *
    *                                                                         *
    * This is a concise, step by step, 'hands on' guide that describes both   *
    * general multitasking concepts and FreeRTOS specifics. It presents and   *
    * explains numerous examples that are written using the FreeRTOS API.     *
    * Full source code for all the examples is provided in an accompanying    *
    * .zip file.                                                              *
    *                                                                         *
    ***************************************************************************

    1 tab == 4 spaces!

    Please ensure to read the configuration and relevant port sections of the
    online documentation.

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

#ifndef PORTMACRO_H
#define PORTMACRO_H

/*-----------------------------------------------------------
 * Port specific definitions.
 *
 * The settings in this file configure FreeRTOS correctly for the
 * given hardware and compiler.
 *
 * These settings should not be altered.
 *-----------------------------------------------------------
 */
#include <avr32/io.h>
#include <dev/avr32/intc.h>
#include <dev/avr32/compiler.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Type definitions. */
#define portCHAR        char
#define portFLOAT       float
#define portDOUBLE      double
#define portLONG        long
#define portSHORT       short
#define portSTACK_TYPE  unsigned portLONG
#define portBASE_TYPE   portLONG

#define TASK_DELAY_MS(x)   ( (x)        /portTICK_RATE_MS )
#define TASK_DELAY_S(x)    ( (x)*1000   /portTICK_RATE_MS )
#define TASK_DELAY_MIN(x)  ( (x)*60*1000/portTICK_RATE_MS )

#define configTICK_TC_IRQ             ATPASTE2(AVR32_TC0_IRQ, configTICK_TC_CHANNEL)

#if( configUSE_16_BIT_TICKS == 1 )
typedef unsigned portSHORT portTickType;
#define portMAX_DELAY ( portTickType ) 0xffff
#else
typedef unsigned portLONG portTickType;
#define portMAX_DELAY ( portTickType ) 0xffffffff
#endif
/*-----------------------------------------------------------*/

/* Architecture specifics. */
#define portSTACK_GROWTH      ( -1 )
#define portTICK_RATE_MS      ( ( portTickType ) 1000 / configTICK_RATE_HZ )
#define portBYTE_ALIGNMENT    4
#define portNOP()             {__asm__ __volatile__ ("nop");}
/*-----------------------------------------------------------*/

/*-----------------------------------------------------------*/

/* INTC-specific. */
#define DISABLE_ALL_EXCEPTIONS()    Disable_global_exception()
#define ENABLE_ALL_EXCEPTIONS()     Enable_global_exception()

#define DISABLE_ALL_INTERRUPTS()    Disable_global_interrupt()
#define ENABLE_ALL_INTERRUPTS()     Enable_global_interrupt()

#define DISABLE_INT_LEVEL(int_lev)  Disable_interrupt_level(int_lev)
#define ENABLE_INT_LEVEL(int_lev)   Enable_interrupt_level(int_lev)

/* Critical section management. */
#define portDISABLE_INTERRUPTS()  DISABLE_ALL_INTERRUPTS()
#define portENABLE_INTERRUPTS()   ENABLE_ALL_INTERRUPTS()

extern void vPortEnterCritical(void);
extern void vPortExitCritical(void);

#define portENTER_CRITICAL()      vPortEnterCritical();
#define portEXIT_CRITICAL()       vPortExitCritical();

/* Added as there is no such function in FreeRTOS. */
extern void *pvPortRealloc(void *pv, size_t xSize);

/*===========================================================================*/

// Task context stack layout:
// R8
// R9
// R10
// R11
// R12
// R14/LR
// R15/PC
// SR
// R0
// R1
// R2
// R3
// R4
// R5
// R6
// R7
// ulCriticalNesting

/*===========================================================================*/

/*
 * Restore Context for cases other than INTi.
 */
#define portRESTORE_CONTEXT()                                                   \
{                                                                               \
  extern volatile unsigned portLONG ulCriticalNesting;                          \
  extern volatile void *volatile pxCurrentTCB;                                  \
                                                                                \
  __asm__ __volatile__ (                                                        \
    /* Set SP to point to new stack */                                          \
    "mov     r8, LO(%[pxCurrentTCB])                                      \n\t" \
    "orh     r8, HI(%[pxCurrentTCB])                                      \n\t" \
    "ld.w    r0, r8[0]                                                    \n\t" \
    "ld.w    sp, r0[0]                                                    \n\t" \
                                                                                \
    /* Restore ulCriticalNesting variable */                                    \
    "ld.w    r0, sp++                                                     \n\t" \
    "mov     r8, LO(%[ulCriticalNesting])                                 \n\t" \
    "orh     r8, HI(%[ulCriticalNesting])                                 \n\t" \
    "st.w    r8[0], r0                                                    \n\t" \
                                                                                \
    /* Restore R0..R7 */                                                        \
    "ldm     sp++, r0-r7                                                  \n\t" \
    /* R0-R7 should not be used below this line */                              \
    /* Skip PC and SR (will do it at the end) */                                \
    "sub     sp, -2*4                                                     \n\t" \
    /* Restore R8..R12 and LR */                                                \
    "ldm     sp++, r8-r12, lr                                             \n\t" \
    /* Restore SR */                                                            \
    "ld.w    r0, sp[-8*4]\n\t" /* R0 is modified, is restored later. */         \
    "mtsr    %[SR], r0                                                    \n\t" \
    /* Restore r0 */                                                            \
    "ld.w    r0, sp[-9*4]                                                 \n\t" \
    /* Restore PC */                                                            \
    "ld.w    pc, sp[-7*4]"                                                      \
    :                                                                           \
    : [ulCriticalNesting] "i" (&ulCriticalNesting),                             \
      [pxCurrentTCB] "i" (&pxCurrentTCB),                                       \
      [SR] "i" (AVR32_SR)                                                       \
  );                                                                            \
}

/*
 * portSAVE_CONTEXT_INT() and portRESTORE_CONTEXT_INT(): for INT0..3 exceptions.
 * portSAVE_CONTEXT_SCALL() and portRESTORE_CONTEXT_SCALL(): for the scall exception.
 *
 * Had to make different versions because registers saved on the system stack
 * are not the same between INT0..3 exceptions and the scall exception.
 */

/*
 * The ISR used for the scheduler tick depends on whether the cooperative or
 * the preemptive scheduler is being used.
 */
#if configUSE_PREEMPTION == 0
/*
 * portSAVE_CONTEXT_INT() for OS Tick exception.
 */
#define portSAVE_CONTEXT_INT(CONTEXT_RAR_REG, CONTEXT_RSR_REG)                  \
{                                                                               \
  __asm__ __volatile__ (                                                        \
    /* save R8..R12, LR */                                                      \
    "stm    --sp, r8-r12, lr                                              \n\t" \
                                                                                \
    /* save PC and SR */                                                        \
    "mfsr   r8, %[RAR]                                                    \n\t" \
    "mfsr   r9, %[RSR]                                                    \n\t" \
    "stm    --sp, r8-r9                                                   \n\t" \
                                                                                \
    /* Save R0..R7 */                                                           \
    "stm    --sp, r0-r7                                                   \n\t" \
    :                                                                           \
    : [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
                                                                                \
  /* With the cooperative scheduler, as there is no context switch by       */  \
  /* interrupt, there is also no context save.                              */  \
}

/*
 * portRESTORE_CONTEXT_INT() for Tick exception.
 */
#define portRESTORE_CONTEXT_INT(CONTEXT_RAR_REG, CONTEXT_RSR_REG)               \
{                                                                               \
  __asm__ __volatile__ (                                                        \
    /* Restore R0..R7 */                                                        \
    "ldm    sp++, r0-r7                                                   \n\t" \
                                                                                \
    /* Restore PC and SR */                                                     \
    "ldm    sp++, r8-r9                                                   \n\t" \
    "mtsr   %[RAR], r8                                                    \n\t" \
    "mtsr   %[RSR], r9                                                    \n\t" \
                                                                                \
    /* Restore R8..R12, LR */                                                   \
    "ldm    sp++, r8-r12, lr                                              \n\t" \
                                                                                \
    /* RETE restores SR and PC from shadow registers                        */  \
    "rete"                                                                      \
    :                                                                           \
    : [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
                                                                                \
  /* With the cooperative scheduler, as there is no context switch by       */  \
  /* interrupt, there is also no context restore.                           */  \
}

#else

/*
 * portSAVE_CONTEXT_INT() for OS Tick exception.
 */
#define portSAVE_CONTEXT_INT(CONTEXT_RAR_REG, CONTEXT_RSR_REG)                  \
{                                                                               \
  extern volatile unsigned portLONG ulCriticalNesting;                          \
  extern volatile void *volatile pxCurrentTCB;                                  \
                                                                                \
  __asm__ __volatile__ (                                                        \
    /* save R8..R12, LR */                                                      \
    "stm    --sp, r8-r12, lr                                              \n\t" \
                                                                                \
    /* save PC and SR */                                                        \
    "mfsr   r8, %[RAR]                                                    \n\t" \
    "mfsr   r9, %[RSR]                                                    \n\t" \
    "stm    --sp, r8-r9                                                   \n\t" \
                                                                                \
    /* Save R0..R7 */                                                           \
    "stm    --sp, r0-r7                                                   \n\t" \
                                                                                \
    /* Arriving here we have the following stack organizations: */              \
    /* R8..R12, LR, PC, SR, R0..R7. */                                          \
                                                                                \
    /* Save ulCriticalNesting variable  - R0 is overwritten */                  \
    "mov    r8, LO(%[ulCriticalNesting])\n\t"                                   \
    "orh    r8, HI(%[ulCriticalNesting])\n\t"                                   \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "st.w   --sp, r0                                                      \n\t" \
                                                                                \
    /* Check if INT0 or higher were being handled (case where the OS tick   */  \
    /* interrupted another interrupt handler (which was of a higher         */  \
    /* priority level but decided to lower its priority level and allow     */  \
    /* other lower interrupt level to occur). In this case we don't want    */  \
    /* to do a task switch because we don't know what the stack currently   */  \
    /* looks like (we don't know what the interrupted interrupt handler was */  \
    /* doing). Saving SP in pxCurrentTCB and then later restoring it        */  \
    /* (thinking restoring the task) will just be restoring the interrupt   */  \
    /* handler, no way!!! So, since we won't do a vTaskSwitchContext(),     */  \
    /* it's of no use to save SP.                                           */  \
                                                                                \
    /* Read SR in stack */                                                      \
    "ld.w   r0, sp[9*4]                                                   \n\t" \
    /* Extract the mode bits to R0. */                                          \
    "bfextu r0, r0, 22, 3                                                 \n\t" \
    /* Compare the mode bits with supervisor mode(b'001) */                     \
    "cp.w   r0, 1                                                         \n\t" \
    "brhi   LABEL_INT_SKIP_SAVE_CONTEXT_%[LINE]                           \n\t" \
                                                                                \
    /* Store SP in the first member of the structure pointed to by          */  \
    /* pxCurrentTCB                                                         */  \
    /* NOTE: we don't enter a critical section here because all interrupt   */  \
    /* handlers MUST perform a SAVE_CONTEXT/RESTORE_CONTEXT in the same way */  \
    /* as portSAVE_CONTEXT_OS_INT/port_RESTORE_CONTEXT_OS_INT if they call  */  \
    /* OS functions.                                                        */  \
    /* => all interrupt handlers must use portENTER_SWITCHING_ISR           */  \
    /* and portEXIT_SWITCHING_ISR.                                          */  \
    "mov    r8, LO(%[pxCurrentTCB])                                       \n\t" \
    "orh    r8, HI(%[pxCurrentTCB])                                       \n\t" \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "st.w   r0[0], sp                                                     \n  " \
                                                                                \
    "LABEL_INT_SKIP_SAVE_CONTEXT_%[LINE]:"                                      \
    :                                                                           \
    : [ulCriticalNesting] "i" (&ulCriticalNesting),                             \
      [pxCurrentTCB] "i" (&pxCurrentTCB),                                       \
      [LINE] "i" (__LINE__),                                                    \
      [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
}

/*
 * portRESTORE_CONTEXT_OS_INT() for Tick exception.
 */
#define portRESTORE_CONTEXT_INT(CONTEXT_RAR_REG, CONTEXT_RSR_REG)               \
{                                                                               \
  extern volatile unsigned portLONG ulCriticalNesting;                          \
  extern volatile void *volatile pxCurrentTCB;                                  \
                                                                                \
  /* Check if INT0 or higher were being handled (case where the OS tick     */  \
  /* interrupted another interrupt handler (which was of a higher priority  */  \
  /* level but decided to lower its priority level and allow other lower    */  \
  /* interrupt level to occur). In this case we don't want to do a task     */  \
  /* switch because we don't know what the stack currently looks like (we   */  \
  /* don't know what the interrupted interrupt handler was doing). Saving   */  \
  /* SP in pxCurrentTCB and then later restoring it (thinking restoring the */  \
  /* task) will just be restoring the interrupt handler, no way!!!          */	\
  __asm__ __volatile__ (                                                        \
    /* Read SR in stack */                                                      \
    "ld.w   r0, sp[9*4]                                                   \n\t" \
    /* Extract the mode bits to R0. */                                          \
    "bfextu r0, r0, 22, 3                                                 \n\t" \
    /* Compare the mode bits with supervisor mode(b'001) */                     \
    "cp.w   r0, 1                                                         \n\t" \
    "brhi   LABEL_INT_SKIP_RESTORE_CONTEXT_%[LINE]"                             \
    :                                                                           \
    : [LINE] "i" (__LINE__)                                                     \
  );                                                                            \
                                                                                \
  /* because it is here safe, always call vTaskSwitchContext() since an     */  \
  /* OS tick occurred. A critical section has to be used here because       */  \
  /* vTaskSwitchContext handles FreeRTOS linked lists.                      */  \
  portENTER_CRITICAL();                                                         \
  vTaskSwitchContext();                                                         \
  portEXIT_CRITICAL();                                                          \
                                                                                \
  /* Restore all registers */                                                   \
                                                                                \
  __asm__ __volatile__ (                                                        \
    /* Set SP to point to new stack */                                          \
    "mov    r8, LO(%[pxCurrentTCB])                                       \n\t" \
    "orh    r8, HI(%[pxCurrentTCB])                                       \n\t" \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "ld.w   sp, r0[0]                                                     \n  " \
                                                                                \
    "LABEL_INT_SKIP_RESTORE_CONTEXT_%[LINE]:                              \n\t" \
                                                                                \
    /* Restore ulCriticalNesting variable */                                    \
    "ld.w    r0, sp++                                                     \n\t" \
    "mov     r8, LO(%[ulCriticalNesting])                                 \n\t" \
    "orh     r8, HI(%[ulCriticalNesting])                                 \n\t" \
    "st.w    r8[0], r0                                                    \n\t" \
                                                                                \
    /* Restore R0..R7 */                                                        \
    "ldm    sp++, r0-r7                                                   \n\t" \
                                                                                \
    /* Restore PC and SR */                                                     \
    "ldm    sp++, r8-r9                                                   \n\t" \
    "mtsr   %[RAR], r8                                                    \n\t" \
    "mtsr   %[RSR], r9                                                    \n\t" \
                                                                                \
    /* Restore R8..R12, LR */                                                   \
    "ldm    sp++, r8-r12, lr                                              \n\t" \
                                                                                \
    /* RETE restores SR and PC from shadow registers                        */  \
    "rete"                                                                      \
    :                                                                           \
    : [ulCriticalNesting] "i" (&ulCriticalNesting),                             \
      [pxCurrentTCB] "i" (&pxCurrentTCB),                                       \
      [LINE] "i" (__LINE__),                                                    \
      [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
}

#endif

#define portSAVE_CONTEXT_INT0() \
  portSAVE_CONTEXT_INT(AVR32_RAR_INT0, AVR32_RSR_INT0)

#define portSAVE_CONTEXT_INT1() \
  portSAVE_CONTEXT_INT(AVR32_RAR_INT1, AVR32_RSR_INT1)

#define portSAVE_CONTEXT_INT2() \
  portSAVE_CONTEXT_INT(AVR32_RAR_INT2, AVR32_RSR_INT2)

#define portSAVE_CONTEXT_INT3() \
  portSAVE_CONTEXT_INT(AVR32_RAR_INT3, AVR32_RSR_INT3)

#define portRESTORE_CONTEXT_INT0() \
  portRESTORE_CONTEXT_INT(AVR32_RAR_INT0, AVR32_RSR_INT0)

#define portRESTORE_CONTEXT_INT1() \
  portRESTORE_CONTEXT_INT(AVR32_RAR_INT1, AVR32_RSR_INT1)

#define portRESTORE_CONTEXT_INT2() \
  portRESTORE_CONTEXT_INT(AVR32_RAR_INT2, AVR32_RSR_INT2)

#define portRESTORE_CONTEXT_INT3() \
  portRESTORE_CONTEXT_INT(AVR32_RAR_INT3, AVR32_RSR_INT3)

/*
 * portSAVE_CONTEXT_SCALL() for SupervisorCALL exception.
 *
 * NOTE: taskYIELD()(== SCALL) MUST NOT be called in a mode > supervisor mode.
 *
 */
#define portSAVE_CONTEXT_SCALL()                                                \
{                                                                               \
  extern volatile unsigned portLONG ulCriticalNesting;                          \
  extern volatile void *volatile pxCurrentTCB;                                  \
                                                                                \
  /* WARNING NOTE: it is strictly forbidden to call                         */  \
  /* vTaskDelay() and vTaskDelayUntil() OS functions                        */  \
  /* (that result in a taskYield()) in an                                   */  \
  /* interrupt|exception handler.                                           */  \
                                                                                \
  /* SR and PC are stored in shadow registers                               */  \
                                                                                \
  __asm__ __volatile__ (																	                      \
    /* save R8..R12, LR */                                                      \
    "stm    --sp, r8-r12, lr                                              \n\t" \
                                                                                \
    /* save PC and SR */                                                        \
    "mfsr   r8, %[RAR_SUP]                                                \n\t" \
    "mfsr   r9, %[RSR_SUP]                                                \n\t" \
    "stm    --sp, r8-r9                                                   \n\t" \
                                                                                \
    /* Save R0..R7 */                                                           \
    "stm    --sp, r0-r7                                                   \n\t" \
                                                                                \
    /* Arriving here we have the following stack organizations:             */  \
    /* R8..R12, LR, PC, SR, R0..R7.                                         */  \
                                                                                \
    /* Save ulCriticalNesting variable  - R0 is overwritten                 */  \
    "mov    r8, LO(%[ulCriticalNesting])                                  \n\t" \
    "orh    r8, HI(%[ulCriticalNesting])                                  \n\t" \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "st.w   --sp, r0"                                                           \
    :                                                                           \
    : [RAR_SUP] "i" (AVR32_RAR_SUP),                                            \
      [RSR_SUP] "i" (AVR32_RSR_SUP),                                            \
      [ulCriticalNesting] "i" (&ulCriticalNesting)                              \
  );                                                                            \
                                                                                \
  /* Disable the its which may cause a context switch (i.e. cause a change  */  \
  /* of pxCurrentTCB). Basically, all accesses to the pxCurrentTCB          */  \
  /* structure should be put in a critical section because it is a global   */  \
  /* structure.                                                             */  \
  portENTER_CRITICAL();																		                      \
                                                                                \
  /* Store SP in the first member of the structure pointed to by            */  \
  /* pxCurrentTCB                                                           */  \
  __asm__ __volatile__ (																	                      \
    "mov    r8, LO(%[pxCurrentTCB])                                       \n\t" \
    "orh    r8, HI(%[pxCurrentTCB])                                       \n\t" \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "st.w   r0[0], sp"																		                      \
    :                                                                           \
    : [pxCurrentTCB] "i" (&pxCurrentTCB)                                        \
  );                                                                            \
}

/*
 * portRESTORE_CONTEXT() for SupervisorCALL exception.
 */
#define portRESTORE_CONTEXT_SCALL()                                             \
{                                                                               \
  extern volatile unsigned portLONG ulCriticalNesting;                          \
  extern volatile void *volatile pxCurrentTCB;                                  \
                                                                                \
  /* Restore all registers */                                                   \
                                                                                \
  /* Set SP to point to new stack */                                            \
  __asm__ __volatile__ (                                                        \
    "mov    r8, LO(%[pxCurrentTCB])                                       \n\t" \
    "orh    r8, HI(%[pxCurrentTCB])                                       \n\t" \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "ld.w   sp, r0[0]"																		                      \
    :                                                                           \
    : [pxCurrentTCB] "i" (&pxCurrentTCB)                                        \
  );                                                                            \
                                                                                \
  /* Leave pxCurrentTCB variable access critical                            */  \
  /* section                                                                */  \
  portEXIT_CRITICAL();                                                          \
                                                                                \
  __asm__ __volatile__ (																	                      \
    /* Restore ulCriticalNesting variable */                                    \
    "ld.w   r0, sp++                                                      \n\t" \
    "mov    r8, LO(%[ulCriticalNesting])                                  \n\t" \
    "orh    r8, HI(%[ulCriticalNesting])                                  \n\t" \
    "st.w   r8[0], r0                                                     \n\t" \
                                                                                \
    /* Restore R0..R7 */                                                        \
    "ldm    sp++, r0-r7                                                   \n\t" \
                                                                                \
    /* Restore PC and SR */                                                     \
    "ldm    sp++, r8-r9                                                   \n\t" \
    "mtsr   %[RAR_SUP], r8                                                \n\t" \
    "mtsr   %[RSR_SUP], r9                                                \n\t" \
                                                                                \
    /* Restore R8..R12, LR */                                                   \
    "ldm    sp++, r8-r12, lr                                              \n\t" \
                                                                                \
    /* RETS restores SR and PC from shadow registers                        */  \
    "rets                                                                 \n\t" \
    :                                                                           \
    : [RAR_SUP] "i" (AVR32_RAR_SUP),                                            \
      [RSR_SUP] "i" (AVR32_RSR_SUP),                                            \
      [ulCriticalNesting] "i" (&ulCriticalNesting)                              \
  );                                                                            \
}


/*
 * The ISR used depends on whether the cooperative or
 * the preemptive scheduler is being used.
 */
#if configUSE_PREEMPTION == 0

/*
 * ISR entry and exit macros.  These are only required if a task switch
 * is required from the ISR.
 */
#define portENTER_SWITCHING_ISR(CONTEXT_RAR_REG, CONTEXT_RSR_REG)               \
{                                                                               \
  __asm__ __volatile__ (                                                        \
    /* save R8..R12, LR */                                                      \
    "stm    --sp, r8-r12, lr                                              \n\t" \
                                                                                \
    /* save PC and SR */                                                        \
    "mfsr   r8, %[RAR]                                                    \n\t" \
    "mfsr   r9, %[RSR]                                                    \n\t" \
    "stm    --sp, r8-r9                                                   \n\t" \
                                                                                \
    /* Save R0..R7 */                                                           \
    "stm    --sp, r0-r7                                                   \n\t" \
    :                                                                           \
    : [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
                                                                                \
  /* With the cooperative scheduler, as there is no context switch by       */  \
  /* interrupt, there is also no context save.                              */  \
}

/*
 * Input parameter: in R12, boolean. Perform a vTaskSwitchContext() if 1
 */
#define portEXIT_SWITCHING_ISR(CONTEXT_RAR_REG, CONTEXT_RSR_REG)                \
{                                                                               \
  __asm__ __volatile__ (                                                        \
    /* Restore R0..R7 */                                                        \
    "ldm    sp++, r0-r7                                                   \n\t" \
                                                                                \
    /* Restore PC and SR */                                                     \
    "ldm    sp++, r8-r9                                                   \n\t" \
    "mtsr   %[RAR], r8                                                    \n\t" \
    "mtsr   %[RSR], r9                                                    \n\t" \
                                                                                \
    /* Restore R8..R12, LR */                                                   \
    "ldm    sp++, r8-r12, lr                                              \n\t" \
                                                                                \
    /* RETE restores SR and PC from shadow registers                        */  \
    "rete"                                                                      \
    :                                                                           \
    : [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
                                                                                \
  /* With the cooperative scheduler, as there is no context switch by       */  \
  /* interrupt, there is also no context restore.                           */  \
}

#else

/*
 * ISR entry and exit macros.  These are only required if a task switch
 * is required from the ISR.
 */
#define portENTER_SWITCHING_ISR(CONTEXT_RAR_REG, CONTEXT_RSR_REG)               \
{                                                                               \
  extern volatile unsigned portLONG ulCriticalNesting;                          \
  extern volatile void *volatile pxCurrentTCB;                                  \
                                                                                \
  __asm__ __volatile__ (                                                        \
    /* save R8..R12, LR */                                                      \
    "stm    --sp, r8-r12, lr                                              \n\t" \
                                                                                \
    /* save PC and SR */                                                        \
    "mfsr   r8, %[RAR]                                                    \n\t" \
    "mfsr   r9, %[RSR]                                                    \n\t" \
    "stm    --sp, r8-r9                                                   \n\t" \
                                                                                \
    /* Save R0..R7 */                                                           \
    "stm    --sp, r0-r7                                                   \n\t" \
                                                                                \
    /* Arriving here we have the following stack organizations: */              \
    /* R8..R12, LR, PC, SR, R0..R7. */                                          \
                                                                                \
    /* Save ulCriticalNesting variable  - R0 is overwritten */                  \
    "mov    r8, LO(%[ulCriticalNesting])\n\t"                                   \
    "orh    r8, HI(%[ulCriticalNesting])\n\t"                                   \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "st.w   --sp, r0                                                      \n\t" \
                                                                                \
    /* Check if INT0 or higher were being handled (case where the OS tick   */  \
    /* interrupted another interrupt handler (which was of a higher         */  \
    /* priority level but decided to lower its priority level and allow     */  \
    /* other lower interrupt level to occur). In this case we don't want    */  \
    /* to do a task switch because we don't know what the stack currently   */  \
    /* looks like (we don't know what the interrupted interrupt handler was */  \
    /* doing). Saving SP in pxCurrentTCB and then later restoring it        */  \
    /* (thinking restoring the task) will just be restoring the interrupt   */  \
    /* handler, no way!!! So, since we won't do a vTaskSwitchContext(),     */  \
    /* it's of no use to save SP.                                           */  \
                                                                                \
    /* Read SR in stack */                                                      \
    "ld.w   r0, sp[9*4]                                                   \n\t" \
    /* Extract the mode bits to R0. */                                          \
    "bfextu r0, r0, 22, 3                                                 \n\t" \
    /* Compare the mode bits with supervisor mode(b'001) */                     \
    "cp.w   r0, 1                                                         \n\t" \
    "brhi   LABEL_ISR_SKIP_SAVE_CONTEXT_%[LINE]                           \n\t" \
                                                                                \
    /* Store SP in the first member of the structure pointed to by          */  \
    /* pxCurrentTCB                                                         */  \
    "mov    r8, LO(%[pxCurrentTCB])                                       \n\t" \
    "orh    r8, HI(%[pxCurrentTCB])                                       \n\t" \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "st.w   r0[0], sp                                                     \n  " \
                                                                                \
    "LABEL_ISR_SKIP_SAVE_CONTEXT_%[LINE]:"                                      \
    :                                                                           \
    : [ulCriticalNesting] "i" (&ulCriticalNesting),                             \
      [pxCurrentTCB] "i" (&pxCurrentTCB),                                       \
      [LINE] "i" (__LINE__),                                                    \
      [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
}

/*
 * Input parameter: in R12, boolean. Perform a vTaskSwitchContext() if 1
 */
#define portEXIT_SWITCHING_ISR(CONTEXT_RAR_REG, CONTEXT_RSR_REG)                \
{                                                                               \
  extern volatile unsigned portLONG ulCriticalNesting;                          \
  extern volatile void *volatile pxCurrentTCB;                                  \
                                                                                \
  /* Check if INT0 or higher were being handled (case where the OS tick     */  \
  /* interrupted another interrupt handler (which was of a higher priority  */  \
  /* level but decided to lower its priority level and allow other lower    */  \
  /* interrupt level to occur). In this case it's of no use to switch       */  \
  /* context and restore a new SP because we purposedly did not previously  */  \
  /* save SP in its TCB.                                                    */  \
  __asm__ __volatile__ (                                                        \
    /* Read SR in stack */                                                      \
    "ld.w   r0, sp[9*4]                                                   \n\t" \
    /* Extract the mode bits to R0. */                                          \
    "bfextu r0, r0, 22, 3                                                 \n\t" \
    /* Compare the mode bits with supervisor mode(b'001) */                     \
    "cp.w   r0, 1                                                         \n\t" \
    "brhi   LABEL_ISR_SKIP_RESTORE_CONTEXT_%[LINE]                        \n\t" \
                                                                                \
    /* If a switch is required then we just need to call                    */  \
    /* vTaskSwitchContext() as the context has already been saved           */  \
    "cp.w   r12, 1                                                        \n\t" \
    "brne   LABEL_ISR_RESTORE_CONTEXT_%[LINE]"                                  \
    :                                                                           \
    : [LINE] "i" (__LINE__)                                                     \
  );                                                                            \
                                                                                \
  /* A critical section has to be used here because                         */  \
  /* vTaskSwitchContext handles FreeRTOS linked lists.                      */  \
  portENTER_CRITICAL();                                                         \
  vTaskSwitchContext();                                                         \
  portEXIT_CRITICAL();                                                          \
                                                                                \
  /* Restore all registers */                                                   \
  __asm__ __volatile__ (                                                        \
    "LABEL_ISR_RESTORE_CONTEXT_%[LINE]:                                   \n\t" \
    /* Set SP to point to new stack */                                          \
    "mov    r8, LO(%[pxCurrentTCB])                                       \n\t" \
    "orh    r8, HI(%[pxCurrentTCB])                                       \n\t" \
    "ld.w   r0, r8[0]                                                     \n\t" \
    "ld.w   sp, r0[0]                                                     \n  " \
                                                                                \
    "LABEL_ISR_SKIP_RESTORE_CONTEXT_%[LINE]:                              \n\t" \
                                                                                \
    /* Restore ulCriticalNesting variable */                                    \
    "ld.w    r0, sp++                                                     \n\t" \
    "mov     r8, LO(%[ulCriticalNesting])                                 \n\t" \
    "orh     r8, HI(%[ulCriticalNesting])                                 \n\t" \
    "st.w    r8[0], r0                                                    \n\t" \
                                                                                \
    /* Restore R0..R7 */                                                        \
    "ldm    sp++, r0-r7                                                   \n\t" \
                                                                                \
    /* Restore PC and SR */                                                     \
    "ldm    sp++, r8-r9                                                   \n\t" \
    "mtsr   %[RAR], r8                                                    \n\t" \
    "mtsr   %[RSR], r9                                                    \n\t" \
                                                                                \
    /* Restore R8..R12, LR */                                                   \
    "ldm    sp++, r8-r12, lr                                              \n\t" \
                                                                                \
    /* RETE restores SR and PC from shadow registers                        */  \
    "rete"                                                                      \
    :                                                                           \
    : [ulCriticalNesting] "i" (&ulCriticalNesting),                             \
      [pxCurrentTCB] "i" (&pxCurrentTCB),                                       \
      [LINE] "i" (__LINE__),                                                    \
      [RAR] "i" (CONTEXT_RAR_REG),                                              \
      [RSR] "i" (CONTEXT_RSR_REG)                                               \
  );                                                                            \
}

#endif


#define portENTER_SWITCHING_ISR0() \
  portENTER_SWITCHING_ISR(AVR32_RAR_INT0, AVR32_RSR_INT0)

#define portENTER_SWITCHING_ISR1() \
  portENTER_SWITCHING_ISR(AVR32_RAR_INT1, AVR32_RSR_INT1)

#define portENTER_SWITCHING_ISR2() \
  portENTER_SWITCHING_ISR(AVR32_RAR_INT2, AVR32_RSR_INT2)

#define portENTER_SWITCHING_ISR3() \
  portENTER_SWITCHING_ISR(AVR32_RAR_INT3, AVR32_RSR_INT3)

#define portEXIT_SWITCHING_ISR0() \
  portEXIT_SWITCHING_ISR(AVR32_RAR_INT0, AVR32_RSR_INT0)

#define portEXIT_SWITCHING_ISR1() \
  portEXIT_SWITCHING_ISR(AVR32_RAR_INT1, AVR32_RSR_INT1)

#define portEXIT_SWITCHING_ISR2() \
  portEXIT_SWITCHING_ISR(AVR32_RAR_INT2, AVR32_RSR_INT2)

#define portEXIT_SWITCHING_ISR3() \
  portEXIT_SWITCHING_ISR(AVR32_RAR_INT3, AVR32_RSR_INT3)



#define portYIELD() {__asm__ __volatile__ ("scall");}



/* Task function macros as described on the FreeRTOS.org WEB site. */
#define portTASK_FUNCTION_PROTO( vFunction, pvParameters ) void vFunction( void *pvParameters )
#define portTASK_FUNCTION( vFunction, pvParameters ) void vFunction( void *pvParameters )

#ifdef __cplusplus
}
#endif

#endif /* PORTMACRO_H */
