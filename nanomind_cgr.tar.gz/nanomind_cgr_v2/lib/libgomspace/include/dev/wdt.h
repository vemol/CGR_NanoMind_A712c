/*
 * wdt.h
 *
 *  Created on: 29/11/2010
 *      Author: johan
 */

#ifndef WDT_H_
#define WDT_H_

void wdt_clear(void);
void wdt_init(void);
void wdt_disable(void);
void wdt_enable(void);

#endif /* WDT_H_ */
