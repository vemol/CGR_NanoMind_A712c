/*
 * ipsocket.h
 *
 *  Created on: Sep 24, 2010
 *      Author: Martin Dam
 */

#ifndef SOCKET_H_
#define SOCKET_H_
#include <sys/socket.h> /* for socket(), connect(), send(), and recv() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_addr() */
#include <sys/types.h>

#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */

int csp_ip_socket(int family, int socket_type, int protocol);

int csp_ip_connect(int sock, int family, char *ip, int port, char * src_ip);

int csp_ip_send(int sock, __const void *__buf, size_t __n, int __flags);

int csp_ip_bind(int sock, int family, int port, char* ip);

int csp_ip_listen (int sock, int size);

int csp_ip_accept(int sock, struct sockaddr * buf, unsigned int *size);

int csp_ip_recv (int sock, __const void *buf, int __n, int __flags);

int csp_ip_recvfrom(int __fd, void *__restrict __buf, size_t __n, int __flags, __SOCKADDR_ARG __addr, int * __addr_len);

int csp_ip_sendto (int __fd, __const void *__buf, size_t __n, int __flags, __CONST_SOCKADDR_ARG __addr, socklen_t __addr_len);

int csp_ip_close (int sock);

#endif /* SOCKET_H_ */
