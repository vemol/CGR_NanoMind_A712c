/*
 *  bytesize.h
 *
 *  Created by Jeppe Ledet-Pedersen on 14/09/10.
 *  Copyright 2010 GomSpace ApS. All rights reserved.
 *
 */

#ifndef BYTESIZE_H
#define BYTESIZE_H

void bytesize(char *buf, int len, int n);

#endif // BYTESIZE_H
