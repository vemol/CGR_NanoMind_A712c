/**
 * Hash functions
 *
 * Copyright 2010 GomSpace ApS. All rights reserved.
 */

#ifndef HASH_H_
#define HASH_H_

#include <stdlib.h>

/**
 * All hash list items must define a void * next_item as the first element
 */
typedef struct {
	void * next_item;
	uint32_t hash;
} hash_list_t;

/** A hast table is a simple table with fixed length */
typedef struct {
	unsigned int bits;
	unsigned int count;
	hash_list_t * table[];
} hash_table_t;

/**
 * Find element in hash table
 * @param table pointer to hash table
 * @param hash 32-bit hash of object name
 */
void * hash_table_search(hash_table_t * table, uint32_t hash);

/**
 * Insert into hash table
 * @param table hash table handle
 * @param hash 32 bit hash of element
 * @param element pointer to element, must be of type hash_list_t, or else...
 * @return -1 if err, 0 if ok
 */
int hash_table_insert(hash_table_t * table, uint32_t hash, hash_list_t * element);

/**
 * Initialise a hash table
 * @param nr_bits number of bits used for indexing (length = 2^n), max 16
 * @return hash table handle
 */
hash_table_t * hash_table_init(unsigned int nr_bits);

/**
 * Return hash table count
 * @param table pointer to table
 * @return count of elements in table
 */
int hash_table_get_count(hash_table_t * table);

/**
 * Fill a list with hash_list_t types from a hash table,
 * this is useful for looping though all elements in table.
 * @param table pointer to table
 * @param list double pointer to preallocated list must be > hash_list_t* * length
 * @param length max size of allocated buffer. Use hash_table_get_count.
 * @return -1 if error, length otherwise.
 */
int hash_table_fill_element_list(hash_table_t * table, hash_list_t ** list, unsigned int length);

/** List iterate function */
typedef void (*hash_iter_func_t)(unsigned int pos, hash_list_t * entry);

/**
 * Iterate all elements in the hash table and apply function.
 * @param table table to iterate
 * @param apply function to apply
 * @return 0 if ok, negative if error
 */
int hash_table_iterate(hash_table_t * table, hash_iter_func_t apply);

/**
 * Jenkins One-at-a-time hash.
 *
 * The Jenkins hash functions are a collection of (non-cryptographic) hash functions for
 * multi-byte keys designed by Bob Jenkins. They can be used also as checksums to detect
 * accidental data corruption or detect identical records in a database. The first one
 * was formally published in 1997.
 *
 * @param key string pointer
 * @param len length of string
 * @return jenkins one-at-a-time hash
 */
uint32_t hash_jenkins(const char *key, size_t len);

#endif /* HASH_H_ */
