/*
 * test_malloc.h
 *
 *  Created on: 31-08-2009
 *      Author: Administrator
 */

#ifndef TEST_MALLOC_H_
#define TEST_MALLOC_H_

void debug_test_malloc(void);

#endif /* TEST_MALLOC_H_ */
