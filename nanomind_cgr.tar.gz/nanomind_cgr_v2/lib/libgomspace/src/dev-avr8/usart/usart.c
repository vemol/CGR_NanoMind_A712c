/*
	FreeRTOS.org V5.1.1 - Copyright (C) 2003-2008 Richard Barry.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

    ***************************************************************************
    ***************************************************************************
    *                                                                         *
    * SAVE TIME AND MONEY!  We can port FreeRTOS.org to your own hardware,    *
    * and even write all or part of your application on your behalf.          *
    * See http://www.OpenRTOS.com for details of the services we provide to   *
    * expedite your project.                                                  *
    *                                                                         *
    ***************************************************************************
    ***************************************************************************

	Please ensure to read the configuration and relevant port sections of the
	online documentation.

	http://www.FreeRTOS.org - Documentation, latest information, license and
	contact details.

	http://www.SafeRTOS.com - A version that is certified for use in safety
	critical systems.

	http://www.OpenRTOS.com - Commercial support, development, porting,
	licensing and training services.
*/


/* BASIC INTERRUPT DRIVEN SERIAL PORT DRIVER FOR IAR AVR PORT. */


#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>

#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include <dev/usart.h>
#include <util/log.h>

#if defined (__AVR_ATmega128__)
#define MY_SIG_DATA SIG_UART1_DATA
#define MY_SIG_RECV SIG_UART1_RECV
#elif defined (__AVR_ATmega1281__)
#define MY_SIG_DATA SIG_USART1_DATA
#define MY_SIG_RECV SIG_USART1_RECV
#endif

#define serBAUD_DIV_CONSTANT			( ( unsigned portLONG ) 16 )

/* Constants for writing to UCSRB. */
#define serRX_INT_ENABLE				( ( unsigned portCHAR ) 0x80 )
#define serRX_ENABLE					( ( unsigned portCHAR ) 0x10 )
#define serTX_ENABLE					( ( unsigned portCHAR ) 0x08 )
#define serTX_INT_ENABLE				( ( unsigned portCHAR ) 0x20 )

/* Constants for writing to UCSRC. */
#define serUCSRC_SELECT					( ( unsigned portCHAR ) 0x80 )
#define serEIGHT_DATA_BITS				( ( unsigned portCHAR ) 0x06 )

static xQueueHandle xRxedChars;

int prv_usart_putchar(char c, FILE *stream) {
	usart_putc(USART_CONSOLE, c);
	return c;
}

void usart_init(int handle, uint32_t fcpu, uint32_t usart_baud) {

	unsigned portLONG ulBaudRateCounter;
	unsigned portCHAR ucByte;

	/* Create the queues used by the com test task. */
	xRxedChars = xQueueCreate(16, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );

	/* Calculate the baud rate register value from the equation in the
	data sheet. */
	ulBaudRateCounter = ( fcpu / ( serBAUD_DIV_CONSTANT * usart_baud ) ) - ( unsigned portLONG ) 1;

	/* Set the baud rate. */
	ucByte = ( unsigned portCHAR ) ( ulBaudRateCounter & ( unsigned portLONG ) 0xff );
	UBRR1L = ucByte;

	ulBaudRateCounter >>= ( unsigned portLONG ) 8;
	ucByte = ( unsigned portCHAR ) ( ulBaudRateCounter & ( unsigned portLONG ) 0xff );
	UBRR1H = ucByte;

	/* Enable the Rx interrupt.  The Tx interrupt will get enabled
	later. Also enable the Rx and Tx. */
	UCSR1B = _BV(RXCIE1) | _BV(RXEN1) | _BV(TXEN1);

	/* set to 8 data bits, 1 stop bit */
	UCSR1B &= ~(1 << UCSZ12);
	UCSR1C |= (1 << UCSZ11) | (1 << UCSZ10);
#if defined (__AVR_ATmega128__)
	UCSR1C &= ~((1 << UMSEL1) | (1 << UPM11) | (1 << UPM10) | (1 << USBS1));
#elif defined (__AVR_ATmega1281__)
	UCSR1C &= ~((1 << UMSEL11) | (1 << UMSEL10) | (1 << UPM11) | (1 << UPM10) | (1 << USBS1));
#endif

	static FILE mystdout = FDEV_SETUP_STREAM(prv_usart_putchar, NULL, _FDEV_SETUP_WRITE);
	stdout = &mystdout;

}

char usart_getc(int handle) {

	unsigned char c;
	xQueueReceive(xRxedChars, &c, portMAX_DELAY);
	return c;

}

char usart_getc_nblock(int handle) {

	unsigned char c =0;
	xQueueReceive(xRxedChars, &c, 0);
	return c;

}

void usart_putc(int handle, char c) {

	/* Spin lock */
	while(!(UCSR1A & (1 << UDRE1)))
		continue;

	UDR1 = c;

}

void MY_SIG_RECV(void) __attribute__((signal));
void MY_SIG_RECV(void) {
	static signed portBASE_TYPE xTaskWoken;
	xTaskWoken = pdFALSE;
	xQueueSendToBackFromISR(xRxedChars, (unsigned char *) 0xCE, &xTaskWoken);
	if (xTaskWoken == pdTRUE)
		portYIELD();
}

int usart_messages_waiting(int handle) {
	return uxQueueMessagesWaiting(xRxedChars);
}
