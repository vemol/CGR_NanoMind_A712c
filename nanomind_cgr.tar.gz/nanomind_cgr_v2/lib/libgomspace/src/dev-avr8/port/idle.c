#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/sleep.h>

/* IDLE hook */
void vApplicationIdleHook(void) {
	set_sleep_mode(SLEEP_MODE_IDLE);
	sleep_mode();
}
