#include <stdint.h>
#include <stdio.h>
#include <util/hexdump.h>

#include <freertos/FreeRTOS.h>
#include <dev/avr32/gpio.h>

#include "mt48lc16m16a2.h"
#include "sdramc_uc3a.h"

int sdram_test(void * start_addr, unsigned int length) {
	uint32_t * sdram;
	int errors = 0;

	/* Write to memory */
	sdram = (uint32_t *) start_addr;
	for (; sdram < (uint32_t*) (start_addr + length); sdram++)
		*sdram = (uint32_t) sdram;

	/* Corrupt some memory */
	//*((unsigned char *) start_addr + length / 2) = 'A';
	//*((unsigned char *) start_addr + length / 3) = 'B';
	//*((unsigned char *) start_addr + length / 4) = 'C';

	/* Read from memory */
	sdram = (uint32_t *) start_addr;
	for (; sdram < (uint32_t*) (start_addr + length); sdram++) {
		if (*sdram != (uint32_t) sdram) {
			printf("MEMORY ERROR\r\n");
			hex_dump(sdram-0x08, 0x10);
			errors++;
		}
	}

	return errors;

	/*
	sdram = (uint32_t *) start_addr;
	hex_dump(sdram+0x0, 0x10);
	hex_dump(sdram+0x100000, 0x10);
	hex_dump(sdram+0x200000, 0x10);
	hex_dump(sdram+0x300000, 0x10);
	hex_dump(sdram+0x400000, 0x10);
	hex_dump(sdram+0x500000, 0x10);
	hex_dump(sdram+0x600000, 0x10);
	hex_dump(sdram+0x700000, 0x10);
	hex_dump(sdram+0x800000-4, 0x20);
	*/

}

/**
 * SDRAM_INIT
 * This function can be called multiple times
 */
void sdram_init(unsigned int cas) {

	volatile uint32_t * sdram = (void *) AVR32_EBI_CS1_ADDRESS;
	volatile int i, j;

	/* Enable multiplexed EBI pins */
	volatile avr32_gpio_port_t *gpio_port;

	/* PORTB: Pins: (42, 43, 44, 45, 46, 47) >> 32 */
	unsigned int port_mask = 0x00017C00;
	gpio_port = &AVR32_GPIO.port[1];
	gpio_port->pmr0c = port_mask;
	gpio_port->pmr1s = port_mask;
	gpio_port->gperc = port_mask;

	/* PORTC: All pins */
	gpio_port = &AVR32_GPIO.port[2];
	gpio_port->pmr0c = 0xFFFFFFFF;
	gpio_port->pmr1c = 0xFFFFFFFF;
	gpio_port->gperc = 0xFFFFFFFF;

	/* PORTX: All pins */
	gpio_port = &AVR32_GPIO.port[3];
	gpio_port->pmr0c = 0xFFFFFFFF;
	gpio_port->pmr1c = 0xFFFFFFFF;
	gpio_port->gperc = 0xFFFFFFFF;

	/* Enable SDRAM mode for CS1. */
	AVR32_HMATRIX.sfr[AVR32_EBI_HMATRIX_NR] |= 1 << AVR32_EBI_SDRAM_CS;
	AVR32_HMATRIX.sfr[AVR32_EBI_HMATRIX_NR];

	/* Memory Device Register */
	AVR32_SDRAMC.MDR.md = AVR32_SDRAMC_MDR_MD_SDRAM;

	/* Send a NOP to turn on the clock (necessary on some chips) */
	AVR32_SDRAMC.mr = AVR32_SDRAMC_MODE_NOP;
	AVR32_SDRAMC.mr;
	sdram[0] = 0;

	/* Insert delay */
	for (j = 0; j < (int) ((double) SDRAM_STABLE_CLOCK_INIT_DELAY / (double) (1000000.0 / (double) 60000000)); j++);

	/* Precharge All command is issued to the SDRAM */
	AVR32_SDRAMC.mr = AVR32_SDRAMC_MR_MODE_BANKS_PRECHARGE;
	AVR32_SDRAMC.mr;
	sdram[0] = 0;

	/* Provide SDRAM_INIT_AUTO_REFRESH_COUNT auto-refresh (CBR) cycles */
	AVR32_SDRAMC.mr = AVR32_SDRAMC_MR_MODE_AUTO_REFRESH;
	AVR32_SDRAMC.mr;
	for (i = 0; i < SDRAM_INIT_AUTO_REFRESH_COUNT; i++)
		sdram[0] = 0;

	/* A mode register set (MRS) cycle is issued to program
	 * SDRAM parameters, in particular CAS latency and burst length.
	 */
	AVR32_SDRAMC.mr = AVR32_SDRAMC_MR_MODE_LOAD_MODE;
	AVR32_SDRAMC.mr;
	sdram[cas << 4] = 0;

	/* A Normal Mode command is provided, 3 clocks after tMRD is met. */
	AVR32_SDRAMC.mr;
	AVR32_SDRAMC.mr = AVR32_SDRAMC_MR_MODE_NORMAL;
	AVR32_SDRAMC.mr;
	sdram[0] = 0;

}

/**
 * Sets various timing variables that are dependent on the HSB speed
 * @param hsb_hz HSB speed in Hz.
 */
void sdram_set_timing(unsigned long hsb_hz, unsigned int cas) {

	int twr, trc, trp, trcd, tras, txsr, cycle_ns;

	/** Calculate timing */
	cycle_ns = (1000000000 / hsb_hz);

	/* CAS: Coloumn address strobe */
	if (cas == 0) {
		if (hsb_hz >= SDRAM_CAS_2_MAX_SPEED) {
			cas = 3;
		} else {
			cas = 2;
		}
	}

	/* TWR: Write recovery time, not dependant on clock speed */
	twr = SDRAM_TWR;

	/* TRC: Row Cycle Time */
	trc = (SDRAM_TRC_MIN_NS / cycle_ns) + 1;

	/* TRP: Precharge to refresh/row activate command */
	trp = (SDRAM_TRP_MIN_NS / cycle_ns) + 1;

	/* TRCD: RAS# to CAS# delay */
	trcd = (SDRAM_TRCD_MIN_NS / cycle_ns) + 1;

	/* TRAS: Row activate to precharge time */
	/* ERRATA: tras = (SDRAM_TRAS_MIN_NS / cycle_ns) + 1;
	 * Due to an error in the SDRAM controller, tras has to be trc + 1.
	 */
	tras = trc + 1;

	/* TXSR: Exit SELF REFRESH to ACTIVE command delay */
	txsr = (SDRAM_TXSR_MIN_NS / cycle_ns) + 1;

	/* Setup SDRAM controller */
	AVR32_SDRAMC.cr =
		( (SDRAM_COL_BITS - 8) << AVR32_SDRAMC_CR_NC ) |
		( (SDRAM_ROW_BITS - 11) << AVR32_SDRAMC_CR_NR ) |
		( (SDRAM_BANK_BITS - 1) << AVR32_SDRAMC_CR_NB ) |
		( cas << AVR32_SDRAMC_CR_CAS ) |
		( twr << AVR32_SDRAMC_CR_TWR ) |
		( trc << AVR32_SDRAMC_CR_TRC ) |
		( trp << AVR32_SDRAMC_CR_TRP ) |
		( trcd << AVR32_SDRAMC_CR_TRCD ) |
		( tras << AVR32_SDRAMC_CR_TRAS ) |
		( txsr << AVR32_SDRAMC_CR_TXSR ) |
		( AVR32_SDRAMC_CR_DBW_16_BITS << AVR32_SDRAMC_CR_DBW );

	/* Set power mode 1 = Self Refresh, 2 = Low power assisted refresh, 0 = Off */
	AVR32_SDRAMC.LPR.lpcb = AVR32_SDRAMC_LPR_LPCB_NO_LP;

}

/**
 * Sets SDRAM auto refresh rate that are dependent on the HSB speed
 * @param hsb_hz HSB speed in Hz.
 */
void sdram_set_refresh_rate(unsigned long hsb_hz) {

	/* Write refresh rate into SDRAMC refresh timer count register */
	volatile avr32_sdramc_t * sdramc = &AVR32_SDRAMC;
	sdramc->tr = SDRAM_TR_NS / (1000000000 / hsb_hz);

}
