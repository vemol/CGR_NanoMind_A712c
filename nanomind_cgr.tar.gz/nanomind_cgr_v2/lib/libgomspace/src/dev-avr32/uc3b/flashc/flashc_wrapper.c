/*
 * flashc_wrapper.c
 *
 *  Created on: 22-08-2009
 *      Author: Administrator
 */

#if 0
// Upper Layer
#include <dev/flash.h>
#include <util/error.h>

// Lower Layer
#include <dev/avr32/flashc.h>

char *dev_flash_errmsg(int err) {
	return "Unimplemented flash driver";
}
int dev_flash_hwr_init(void) {
	return E_NO_DEVICE;
}
int dev_flash_erase(void* block, unsigned int size) {
	return E_NO_DEVICE;
}
int dev_flash_program(void* addr, void* data, int len) {
	return E_NO_DEVICE;
}
void dev_flash_test_program_buf(void) {
	return;
}
void dev_flash_test_erase(void) {
	return;
}
#endif
