/* This source file is part of the ATMEL AVR32-SoftwareFramework-AT32UC3B-1.4.0 Release */

/*This file is prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief NEWLIB_ADDONS system calls overloading file for AVR32.
 *
 * - Compiler:           GNU GCC for AVR32
 * - Supported devices:  All AVR32 devices can be used.
 * - AppNote:
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support and FAQ: http://support.atmel.no/
 *
 ******************************************************************************/

/* Copyright (C) 2006-2008, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <conf_gomspace.h>

#include <sys/times.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dev/usart.h>
#include <dev/cpu.h>
//#include "nlao_io.h"
//#include "nlao_usart.h"
//#include "nlao_interrupts.h"
//#include "nlao_exceptions.h"

#include <avr32/io.h>
#include <dev/usart.h>

#define AVR32_COUNT                                    0x00000108

/* libgomspace cannot depend on libstorage, so we have to declare these symbols weak */
__attribute__ ((weak)) int vfs_open(const char *path, int oflag, int mode);
__attribute__ ((weak)) int vfs_close(int fildes);
__attribute__ ((weak)) int vfs_read(int fildes, void *buf, int nbyte);
__attribute__ ((weak)) int vfs_write(int fildes, const void *buf, int nbyte);
__attribute__ ((weak)) off_t vfs_lseek(int fildes, off_t offset, int whence);
__attribute__ ((weak)) int vfs_fstat(int fildes, struct stat *buf);
__attribute__ ((weak)) int vfs_stat(const char *path, struct stat *buf);
__attribute__ ((weak)) int vfs_fsync(int fildes);
__attribute__ ((weak)) int vfs_unlink(const char *path);
__attribute__ ((weak)) int vfs_link(const char *oldpath, const char *newpath);
__attribute__ ((weak)) int vfs_rename(const char *oldpath, const char *newpath);

int _read(int file, void *ptr, size_t len) {

	if (file <= STDERR_FILENO) {
		*(char *) ptr = usart_getc(USART_CONSOLE);
		if ((*(char *) ptr != '\n') && (*(char *) ptr != '\r'))
			usart_putc(USART_CONSOLE, *(char *) ptr);
		return 1;
	} else {
		if (vfs_read)
			return vfs_read(file, ptr, len);
		return -1;
	}

}

int _write(int file, const void *ptr, size_t len) {

	size_t i;

	if (file <= STDERR_FILENO) {
		for(i = 0; i < len; i++) {
			if (((const char *) ptr)[i] == '\n')
				usart_putc(USART_CONSOLE, '\r');
			usart_putc(USART_CONSOLE, ((const char *) ptr)[i]);
		}
		return len;
	} else {
		if (vfs_write)
			return vfs_write(file, ptr, len);
		return -1;
	}

}

off_t _lseek(int file, off_t ptr, int dir) {
	if (file <= STDERR_FILENO) {
		return -1;
	} else {
		if (vfs_lseek)
			return vfs_lseek(file, ptr, dir);
		return -1;
	}
}

int _close(int file) {
	if (file <= STDERR_FILENO) {
		return -1;
	} else {
		if (vfs_close)
			return vfs_close(file);
		return -1;
	}
}

int _open(const char *name, int flags, ...) {
	if (vfs_open)
		return vfs_open(name, flags, 0);
	return -1;
}

int _link(const char *oldpath, const char *newpath) {
	if (vfs_link)
		return vfs_link(oldpath, newpath);
	return -1;
}

int _rename(const char *oldpath, const char *newpath) {
	if (vfs_rename)
		return vfs_rename(oldpath, newpath);
	return -1;
}

int _unlink(const char *pathname) {
	if (vfs_unlink)
		return vfs_unlink(pathname);
	return -1;
}

int fsync(int fd) {
	if (fd <= STDERR_FILENO) {
		return -1;
	} else {
		if (vfs_fsync)
			return vfs_fsync(fd);
		return -1;
	}
}

int _fstat(int fd, struct stat *st) {
	if (fd <= STDERR_FILENO) {
		return -1;
	} else {
		if (vfs_fstat)
			return vfs_fstat(fd, (struct stat *) st);
		return -1;
	}
}

int _stat(const char *path, struct stat *st) {
	if (vfs_stat)
		return vfs_stat(path, (struct stat *) st);
	return -1;
}

int _isatty(int fd) {
	if (fd <= STDERR_FILENO)
		return 1;
	else
		return 0;
}


int __attribute__((weak))
unimplemented_syscall(char *name) {
#ifdef DEBUG_MSG_ON
	fprintf(stderr, "Error: Unimplemented syscall: %\n", name);
#endif
	return -1;
}

int __attribute__((weak))
_fcntl() {
	return unimplemented_syscall("_fcntl");
}

int __attribute__((weak))
_kill() {
	return unimplemented_syscall("_kill");
}

int __attribute__((weak))
_getpid() {
	return unimplemented_syscall("_getpid");
}

int __attribute__((weak))
_gettimeofday() {
	return unimplemented_syscall("_gettimeofday");
}

int __attribute__((weak))
_execve() {
	return unimplemented_syscall("_execve");
}

int __attribute__((weak))
_fork() {
	return unimplemented_syscall("_fork");
}

int __attribute__((weak))
_wait() {
	return unimplemented_syscall("_wait");
}

int __attribute__((weak))
sigfillset() {
	return unimplemented_syscall("sigfillset");
}

int __attribute__((weak))
sigprocmask() {
	return unimplemented_syscall("sigprocmask");
}

clock_t __attribute__((weak))
_times(struct tms *tms) {
	int tick;
	tick = __builtin_mfsr(AVR32_COUNT);
	tms->tms_utime = 0;
	tms->tms_stime = tick;
	tms->tms_cutime = 0;
	tms->tms_cstime = 0;
	return tick;
}

extern void __heap_start__, __heap_end__;

void * __attribute__((weak))
_sbrk(int increment) {
	static void *cur_heap_pos = 0;

	//Initialize cur_heap_pos
	if (cur_heap_pos == 0)
		cur_heap_pos = &__heap_start__;

#if defined(__AVR32_UC3A0512__)
	if ((cur_heap_pos + increment) >= (void *) &__heap_end__) {
#else
	if ((cur_heap_pos + increment) >= (void *) 0x8000) {
#endif
#if 0
		extern unsigned long __malloc_top_pad;
		printf("Top pad %lu\r\n", __malloc_top_pad);
		printf("Warning: Heap is running full trying to allocate %i bytes!!!!\r\n", increment);
		printf("\tHeap start address\t= %p\r\n", &__heap_start__);
		printf("\tHeap end address\t= %p\r\n", (void *) &__heap_end__);
		printf("\tCurrent heap address\t= %p\r\n", cur_heap_pos);
#endif
		errno = ENOMEM;
		return (void *) -1;
	}

	void * old_heap_pos = cur_heap_pos;
	cur_heap_pos += increment;
	return old_heap_pos;

}

/**
 * Low-level open operator.
 * Will return integer 3 if you open the "/dev/fb" framebuffer.
 * The user will never use this command, only call fopen("fb", "a") to get a
 * FILE handle.
 * This can in the future be extended to open MMC files.
 */
/*int __do_not_use_oscall_coproc__;
 static void *do_not_use_oscall_coproc = &__do_not_use_oscall_coproc__;*/

void __attribute__((weak))
_init_argv() {
	/*  if ( !do_not_use_oscall_coproc )
	 _init_argv_sim();*/
}

void __attribute__((weak))
_exit(int code) {
	/*  if ( !do_not_use_oscall_coproc )
	 return _exit_sim(code);*/

	//Signal exit
	printf("\004%d", code);

	//flush all pending writes
	fflush(stdout);
	fflush(stderr);

	cpu_reset();
	while (1);
}
