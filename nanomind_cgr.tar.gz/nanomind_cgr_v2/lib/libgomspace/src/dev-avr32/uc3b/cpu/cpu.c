/*
 * cpu.c
 *
 *  Created on: 22-08-2009
 *      Author: Administrator
 */

#include <stdio.h>
#include <dev/cpu.h>
#include <dev/avr32/wdt.h>

void cpu_reset(void) {
	wdt_reset_mcu();
}
