/*
 * idle.c
 *
 *  Created on: 22-08-2009
 *      Author: Administrator
 */

#include <avr32/io.h>
#include <stdio.h>

#include <dev/avr32/compiler.h>

/*! \brief Sets the MCU in the specified sleep mode.
 *
 * \param mode Sleep mode:
 *   \arg \c AVR32_PM_SMODE_IDLE: Idle;
 *   \arg \c AVR32_PM_SMODE_FROZEN: Frozen;
 *   \arg \c AVR32_PM_SMODE_STANDBY: Standby;
 *   \arg \c AVR32_PM_SMODE_STOP: Stop;
 *   \arg \c AVR32_PM_SMODE_DEEP_STOP: DeepStop;
 *   \arg \c AVR32_PM_SMODE_STATIC: Static.
 */

void vApplicationIdleHook(void) {
	void i2c_hw_poll(void) __attribute__((weak));
	if (i2c_hw_poll != NULL)
		i2c_hw_poll();
	__asm__ __volatile__ ("sleep 0");
}
