/**
 * @file pca9665_isr.c
 * Low level ISR functions for PCA9665 device on NanoCam boards
 *
 * @author Johan De Claville Christiansen
 * Copyright 2011 GomSpace ApS. All rights reserved.
 */

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <avr32/io.h>
#include <dev/cpu.h>
#include <dev/avr32/intc.h>
#include <dev/avr32/gpio.h>
#include <dev/avr32/pm.h>

#include "../src/dev/pca9665/pca9665.h"

/* Number of devices present on board */
const int pca9665_device_count = 1;

/* Setup of each device */
pca9665_device_object_t device[1] = {
	{
		.base = (uint8_t *) 0xD0000000,
		.is_initialised = 0,
		.is_busy = 0,
		.mode = DEVICE_MODE_M_T,
		.callback = NULL,
		.tx.frame = NULL,
		.tx.queue = NULL,
		.rx.queue = NULL,
	}
};

__attribute__((__noinline__)) portBASE_TYPE pca9665_DSR(void) {
	volatile avr32_eic_t * eic = &AVR32_EIC;
	static portBASE_TYPE task_woken;
	task_woken = pdFALSE;
	pca9665_dsr(&task_woken);
	eic->ICR.int6 = 1;
	return task_woken;
}

__attribute__((naked)) void pca9665_ISR(void) {
	portENTER_SWITCHING_ISR();
	pca9665_DSR();
	portEXIT_SWITCHING_ISR();
}

void pca9665_isr_init(void) {

	/* Enable multiplexed EBI pins */
	volatile avr32_gpio_port_t *gpio_port;
	gpio_port = &AVR32_GPIO.port[2];
	gpio_port->pmr0c = 0xFFFFFFFF;
	gpio_port->pmr1c = 0xFFFFFFFF;
	gpio_port->gperc = 0xFFFFFFFF;
	gpio_port = &AVR32_GPIO.port[3];
	gpio_port->pmr0c = 0xFFFFFFFF;
	gpio_port->pmr1c = 0xFFFFFFFF;
	gpio_port->gperc = 0xFFFFFFFF;

	/**
	 * The order of initialisation is important since the SMC must be given
	 * a few moments in order to be stable, before calling the PCA9665.
	 */
	volatile avr32_smc_t * smc = &AVR32_SMC;
	smc->cs[1].MODE.read_mode 		= AVR32_SMC_MODE3_READ_MODE_NRD_CONTROLLED;
	smc->cs[1].MODE.write_mode 		= AVR32_SMC_MODE3_WRITE_MODE_NWE_CONTROLLED;
	smc->cs[1].MODE.exnw_mode		= AVR32_SMC_MODE3_EXNW_MODE_DISABLED;
	smc->cs[1].MODE.dbw 			= AVR32_SMC_MODE3_DBW_8_BITS;
	smc->cs[1].MODE.tdf_cycles = 0;	// Data Float Time (1 clock + tdc_cycles)
	smc->cs[1].MODE.tdf_mode = 0;	// TDF optimization disabled
	smc->cs[1].MODE.pmen = 0;		// Paged mode disabled

	/* Enable Interrupt */
	gpio_enable_module_pin(AVR32_EIC_EXTINT_6_PIN, AVR32_EIC_EXTINT_6_FUNCTION);
	INTC_register_interrupt(&pca9665_ISR, AVR32_EIC_IRQ_6, AVR32_INTC_INT1);
	volatile avr32_eic_t * eic = &AVR32_EIC;

	//eic->MODE.int6 = 0;				// Mode = Edge triggered
	//eic->EDGE.int6 = 0;				// Edge = Falling edge

	eic->MODE.int6 = 1;				// Level Triggered
	eic->LEVEL.int6 = 0;			// Trigger low level

	eic->ICR.int6 = 1;				// Clear interrupt
	eic->IER.int6 = 1;				// Enable External ISR
	eic->EN.int6 = 1;				// Enable

}

