// Standard Includes
#include <avr32/io.h>
#include <string.h>
#include <stdio.h>

// GOMspace Library
#include <dev/i2c.h>
#include <dev/usart.h>
#include <util/error.h>
#include <util/hexdump.h>
#include <util/csp_buffer.h>
#include <util/driver_debug.h>

// AVR32 specific drivers
#include <dev/avr32/gpio.h>
#include <dev/avr32/pdca.h>
#include <dev/avr32/intc.h>
#include <dev/avr32/pm.h>

// FreeRTOS lib
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <freertos/queue.h>

/* Hardware definition */
#define PIN_TWI_CLK				AVR32_TWI_SCL_0_0_PIN
#define PIN_TWI_DATA			AVR32_TWI_SDA_0_0_PIN
#define PDC_CHANNEL_TWI_RX 		3
#define PDC_CHANNEL_TWI_TX 		4

/* Pointer to the instance 1 of the TWI registers for IT. */
static volatile avr32_twi_t *twi = &AVR32_TWI;

/* Semaphores */
static uint8_t i2c_busy = 0;
static portTickType last_tx = 0;

/* IO interfaces */
static xQueueHandle tx_queue;
static xQueueHandle rx_queue;
static i2c_callback_t rx_callback;

/* Options */
static char opt_chip;
static unsigned long opt_speed;
static unsigned long opt_pba_hz;

/* Calculated values */
static unsigned int prv_cldiv;
static unsigned int prv_ckdiv = 0;

/* Pointers for the PDC buffers */
static i2c_frame_t * txbuffer;
static i2c_frame_t * rxbuffer;
static i2c_frame_t * rxreload;

__attribute__((__naked__)) static void twi_master_inst1_interrupt_handler( void );
__attribute__((__naked__)) static void twi_slave_inst1_interrupt_handler( void );

/**
 * Simple helper function to start the hardware in slave mode
 */
static void prv_set_rx(void) {

	driver_debug(DEBUG_I2C, "I2C RX 0x%08lX\r\n", twi->sr);

	i2c_busy = 0;

	/* Disable TWI interrupts */
	twi->idr = ~0UL;

	/* Register TWI handler on level 2 */
	INTC_register_interrupt( &twi_slave_inst1_interrupt_handler, AVR32_TWI_IRQ, AVR32_INTC_INT1);

	if (twi->SR.txcomp == 0)
		driver_debug(DEBUG_I2C, "Error, TXCOMP = 0 in RX\r\n");

	/* Reset the PDC */
	pdca_load_channel(PDC_CHANNEL_TWI_RX, rxbuffer->data, sizeof(i2c_frame_t));

	/* Set slave address */
	twi->smr = (opt_chip << AVR32_TWI_SMR_SADR_OFFSET);

	/* Disable master transfer, enable slave */
	twi->cr = AVR32_TWI_CR_MSDIS_MASK | AVR32_TWI_CR_SVEN_MASK;

	/* Slave Access Interrupt Enable */
	twi->ier = AVR32_TWI_IER_SVACC_MASK | AVR32_TWI_IER_EOSACC_MASK | AVR32_TWI_IER_NACK_MASK;

}

/**
 * Simple helper function to start TX
 * If the I2C driver is not busy and there is something
 * in the TX queue, set start-flag
 */
static inline int prv_try_tx(void) {

	static portBASE_TYPE false_val = pdFALSE;

	if (i2c_busy) {
		return 0;
	}

	if (xQueueIsQueueEmptyFromISR(tx_queue) == pdTRUE) {
		return 0;
	}

	/* First check if the previous frame was completed */
	if (txbuffer != NULL) {
		driver_debug(DEBUG_I2C, "Previous frame was not freed\r\n");
		csp_buffer_free_isr(txbuffer);
	}

	/* Receive next frame for transmission */
	xQueueReceiveFromISR(tx_queue, &txbuffer, &false_val);

	if (txbuffer == NULL) {
		driver_debug(DEBUG_I2C, "Failed to get buffer I2C\r\n");
		return 0;
	}

	/* Start transmission */
	i2c_busy = 1;
	last_tx = xTaskGetTickCountFromISR();
	driver_debug(DEBUG_I2C, "I2C TX 0x%08lX\r\n", twi->sr);

	/* Disable TWI interrupts */
	twi->idr = ~0UL;

	if (twi->SR.txcomp == 0)
		driver_debug(DEBUG_I2C, "Error, TXCOMP = 0 in TX\r\n");

	/* Ensure TX PDC is stopped before starting master */
	pdca_disable(PDC_CHANNEL_TWI_TX);

	/* Register TWI handler on level 2 */
	INTC_register_interrupt(&twi_master_inst1_interrupt_handler, AVR32_TWI_IRQ, AVR32_INTC_INT1);

	/* Set write mode and slave address */
	twi->mmr = (0 << AVR32_TWI_MMR_MREAD_OFFSET) |
		(txbuffer->dest << AVR32_TWI_MMR_DADR_OFFSET);

	/* set clock waveform generator register */
	twi->cwgr = (prv_cldiv | (prv_cldiv << AVR32_TWI_CWGR_CHDIV_OFFSET) | (prv_ckdiv << AVR32_TWI_CWGR_CKDIV_OFFSET));

	/* Mark master transfer */
	twi->cr = AVR32_TWI_CR_MSEN_MASK | AVR32_TWI_CR_SVDIS_MASK;

	/* Start up the PDC */
	pdca_load_channel(PDC_CHANNEL_TWI_TX, txbuffer->data, txbuffer->len);
	pdca_enable(PDC_CHANNEL_TWI_TX);

	/* We want to listen only for certain interrupts */
	twi->ier = AVR32_TWI_IER_TXCOMP_MASK | AVR32_TWI_IER_NACK_MASK | AVR32_TWI_IER_ARBLST_MASK;

	return 1;

}

/**
 * TWI MASTER ISR
 *
 * Note, there is an error in the data sheet. When handling a NACK, we must first catch the NACK
 * interrupt and call Master disable. Following this the TXCOMP interrupt must be caught, and
 * the system must be set back to RX or TX.
 *
 */
static __attribute__((__noinline__))
portBASE_TYPE twi_master_inst1_interrupt_handler_real(void) {

	/* get masked status register value */
	int status = twi->sr;

	driver_debug(DEBUG_I2C, "MISR 0x%08X\r\n", status);
	pdca_disable(PDC_CHANNEL_TWI_TX);

	/* If NOT this is a TXCOMP */
	if (!(status & AVR32_TWI_SR_TXCOMP_MASK)) {

		/* This is a NACK */
		if (status & AVR32_TWI_SR_NACK_MASK) {
			twi->cr = AVR32_TWI_CR_MSDIS_MASK;
			driver_debug(DEBUG_I2C, "I2C NACK\r\n");
			return pdFALSE;
		}

		/* This is a ARBLOST, @todo: Implement arb-lost code */
		if (status & AVR32_TWI_SR_ARBLST_MASK) {
			twi->cr = AVR32_TWI_CR_MSDIS_MASK;
			driver_debug(DEBUG_I2C, "I2C ARBLOST\r\n");
			return pdFALSE;
		}

	}

	if (txbuffer != NULL) {
		csp_buffer_free_isr(txbuffer);
	}
	txbuffer = NULL;

	/* We are done here */
	i2c_busy = 0;
	last_tx = 0;

	if (!prv_try_tx()) {
		prv_set_rx();
	}

	return pdFALSE;

}

__attribute__((__naked__))
static void twi_master_inst1_interrupt_handler( void ) {
	portENTER_SWITCHING_ISR();
	twi_master_inst1_interrupt_handler_real();
	portEXIT_SWITCHING_ISR();
}

/* TWI PDCA RX interrupt handler. */
__attribute__((__noinline__))
static portBASE_TYPE twi_pdca_rx_interrupt_handler_real(void) {

	static portBASE_TYPE xTaskWoken = pdFALSE;
	static unsigned long status;
	static i2c_frame_t * newBuf;

	/* Get status */
	status = pdca_get_transfer_status(PDC_CHANNEL_TWI_RX);
	driver_debug(DEBUG_I2C, "RX PDC 0x%lx\r\n", status);

	/* If two frames received, use load-buffer first */
	if (status & PDCA_TRANSFER_COMPLETE) {
		driver_debug(DEBUG_I2C, "RX PDC Overrun!\r\n");
		goto out;
	}

	/* If no more memory, write to same frame again (loss of packet) */
	if ((newBuf = csp_buffer_get_isr(I2C_MTU)) == NULL) {
		driver_debug(DEBUG_I2C, "Out of memory, loosing data!\r\n");
		goto out;
	}

	newBuf->len_rx = 0;

	//driver_debug(DEBUG_I2C, "Queue up %p newbuf %p\r\n", rxbuffer, newBuf);

	/* If callback is registered */
	if (rx_callback != NULL)
		(*rx_callback)(rxbuffer, &xTaskWoken);
	else
		xQueueSendFromISR(rx_queue, &rxbuffer, &xTaskWoken);

	/* Rotate buffer and reload */
	rxbuffer = rxreload;
	rxreload = newBuf;

out:
	i2c_busy = 0;
	prv_try_tx();

	/* Store the new reload bufer in PDC */
	pdca_reload_channel(PDC_CHANNEL_TWI_RX, &rxreload->data, sizeof(i2c_frame_t));

	return xTaskWoken;

}

__attribute__((__naked__))
static void twi_pdca_rx_interrupt_handler( void )  {
	portENTER_SWITCHING_ISR();
	twi_pdca_rx_interrupt_handler_real();
	portEXIT_SWITCHING_ISR();
}

/* TWI RX interrupt handler. */
__attribute__((__noinline__))
static portBASE_TYPE twi_slave_inst1_interrupt_handler_real(void) {

	/* Get TWI status register */
	int status = twi->sr;

	driver_debug(DEBUG_I2C, "SISR 0x%08X\r\n", status);

	/* End of slave access or NACK detected */
	if ((status & AVR32_TWI_IER_NACK_MASK) || (status & AVR32_TWI_SR_EOSACC_MASK)) {

		/* Signal to PDC that transfer is complete */
		rxbuffer->len = sizeof(i2c_frame_t) - AVR32_PDCA.channel[PDC_CHANNEL_TWI_RX].tcr;
		AVR32_PDCA.channel[PDC_CHANNEL_TWI_RX].tcr = 0;

		/* Change interrupts to wait for frame-start */
		twi->idr = AVR32_TWI_IER_EOSACC_MASK | AVR32_TWI_IER_NACK_MASK;
		twi->ier = AVR32_TWI_IER_SVACC_MASK;

		return pdFALSE;
	}

	/* Start of slave access
	 * Note: This check must be last since it is always true while slave is running */
	if (status & AVR32_TWI_SR_SVACC_MASK) {

		/* Only accept slave-read, never slave-write */
		if (status & AVR32_TWI_SR_SVREAD_MASK) {
			driver_debug(DEBUG_I2C, "I2C Error: Trying slave-write\r\n");
			prv_set_rx();
			return pdFALSE;
		}

		/* Dont accept global call */
		if (status & AVR32_TWI_SR_GACC_MASK) {
			driver_debug(DEBUG_I2C, "I2C Error: Trying global call\r\n");
			prv_set_rx();
			return pdFALSE;
		}

		/* Change interrupt to wait for frame-end */
		twi->idr = AVR32_TWI_IER_SVACC_MASK;
		twi->ier = AVR32_TWI_IER_EOSACC_MASK | AVR32_TWI_IER_NACK_MASK;

		/* Lock the TWI to prevent transmitting while receiving */
		i2c_busy = 1;
		return pdFALSE;

	}

	driver_debug(DEBUG_I2C, "Unknown I2C\r\n");
	return pdFALSE;

}

__attribute__((__naked__))
static void twi_slave_inst1_interrupt_handler(void) {
	portENTER_SWITCHING_ISR();
	twi_slave_inst1_interrupt_handler_real();
	portEXIT_SWITCHING_ISR();
}

/**
 * Try to recover from bus error by checking timeout
 * This function is externally and weakly linked inside the idle() loop
 * thereby calling it for each timer tick.
 */
void i2c_hw_poll(void) {
	if ((last_tx != 0) && ((last_tx + 10) < xTaskGetTickCount())) {
		driver_debug(DEBUG_I2C, "I2C hardware timeout %u + 10 < %u\r\n", (unsigned int) last_tx, (unsigned int) xTaskGetTickCount());
		i2c_busy = 0;
		last_tx = 0;
		twi->cr = AVR32_TWI_CR_MSDIS_MASK;
		prv_set_rx();
		portENTER_CRITICAL();
		prv_try_tx();
		portEXIT_CRITICAL();
	}
}

/**
 * Send I2C frame via the selected device
 *
 * @param handle Handle to the device
 * @param frame Pointer to I2C frame, should contain destination address as first byte!
 * @param timeout Ticks to wait
 * @return Error code as per error.h
 */
int i2c_send(int handle, i2c_frame_t * frame, uint16_t timeout) {

	if ((frame->len == 0) || (frame->len > I2C_MTU))
		return E_INVALID_BUF_SIZE;

	driver_debug(DEBUG_I2C, "I2C send\r\n");

	/* Store pointer to frame and start transmitting */
	/* Note: Blocking send is not supported! */
	if (xQueueSend(tx_queue, &frame, timeout) != pdTRUE) {
		driver_debug(DEBUG_I2C, "I2C Nobuff\r\n");

		/* Try to activate HW before returning, just to ensure TX is still ticking */
		portENTER_CRITICAL();
		prv_try_tx();
		portEXIT_CRITICAL();
		return E_NO_BUFFER;
	}

	/* Try to activate HW */
	portENTER_CRITICAL();
	prv_try_tx();
	portEXIT_CRITICAL();

	return E_NO_ERR;

}

/*! \brief Start up the I2C and TWI Driver.
 *
 * \param rx_queue 	A pre-initialized FreeRTOS message queue
 * \param chip   	The desired chip address.
 * \param speed  	The desired twi bus speed
 * \param pba_hz 	The current running PBA clock frequency
 */
int i2c_init(int handle, int mode, uint8_t addr, uint16_t speed, int queue_len_tx,
		int queue_len_rx, i2c_callback_t callback) {

	/* This driver is multi-master only */
	if (mode != I2C_MASTER)
		return E_NO_DEVICE;

	/* Initialise message queues */
	tx_queue = xQueueCreate(queue_len_tx, sizeof(i2c_frame_t *));
	if (tx_queue == 0)
		return E_OUT_OF_MEM;

	/* Register either callback for create RX queue */
	if (callback != NULL) {
		rx_callback = callback;
	} else {
		rx_queue = xQueueCreate(queue_len_rx, sizeof(i2c_frame_t *));
		if (rx_queue == 0)
			return E_OUT_OF_MEM;
	}

	extern pm_freq_param_t clock_param;
	opt_chip = addr;
	opt_speed = speed * 1000 * 2; // Multiply with 2, since clock = clhigh + cllow
	opt_pba_hz = clock_param.pba_f;

	/* cldiv must fit in 8 bits, ckdiv must fit in 3 bits */
	prv_cldiv = (opt_pba_hz / opt_speed) - 4;
	while ((prv_cldiv > 0xFF) && (prv_ckdiv < 0x7)) {
		prv_ckdiv++;	// increase clock divider
		prv_cldiv /= 2; // divide cldiv value
	}

	/* Memory allocation */
	rxbuffer = csp_buffer_get(I2C_MTU);
	rxreload = csp_buffer_get(I2C_MTU);

	rxbuffer->len_rx = 0;
	rxreload->len_rx = 0;

	/* TWI pin setup */
	gpio_enable_module_pin(PIN_TWI_CLK, AVR32_TWI_SCL_0_0_FUNCTION);
	gpio_enable_module_pin(PIN_TWI_DATA, AVR32_TWI_SDA_0_0_FUNCTION);

	/* Initialize PDCA Slave */
	pdca_channel_options_t pdc_channel_rx;
	pdc_channel_rx.addr = rxbuffer->data;
	pdc_channel_rx.size = sizeof(i2c_frame_t);
	pdc_channel_rx.r_addr = rxreload->data;
	pdc_channel_rx.r_size = sizeof(i2c_frame_t);
	pdc_channel_rx.pid = AVR32_PDCA_PID_TWI_RX;
	pdc_channel_rx.transfer_size = PDCA_TRANSFER_SIZE_BYTE;
	pdca_init_channel(PDC_CHANNEL_TWI_RX, &pdc_channel_rx);
	INTC_register_interrupt(&twi_pdca_rx_interrupt_handler, AVR32_PDCA_IRQ_0+PDC_CHANNEL_TWI_RX, AVR32_INTC_INT1);
	pdca_enable_interrupt_transfer_complete(PDC_CHANNEL_TWI_RX);
	pdca_enable_interrupt_reload_counter_zero(PDC_CHANNEL_TWI_RX);
	pdca_enable(PDC_CHANNEL_TWI_RX);

	/* Initialize PDCA Master */
	pdca_channel_options_t pdc_channel_tx;
	pdc_channel_tx.addr = NULL;
	pdc_channel_tx.size = 0;
	pdc_channel_tx.r_addr = NULL;
	pdc_channel_tx.r_size = 0;
	pdc_channel_tx.pid = AVR32_PDCA_PID_TWI_TX;
	pdc_channel_tx.transfer_size = PDCA_TRANSFER_SIZE_BYTE;
	pdca_init_channel(PDC_CHANNEL_TWI_TX, &pdc_channel_tx);

	prv_set_rx();

	return E_NO_ERR;

}
