/*
 * spi_wrapper.c
 *
 *  Created on: 27-11-2009
 *      Author: Administrator
 */

#include <stdio.h>
#include <stdint.h>
#include <avr32/io.h>

#include <dev/avr32/intc.h>
#include <dev/avr32/gpio.h>
#include <dev/avr32/pm.h>
#include <dev/avr32/pdca.h>
#include <dev/spi.h>

#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <freertos/task.h>

#include "spi.h"

#define PDC_CHANNEL_SPI_TX	10
#define PDC_CHANNEL_SPI_RX	11

#define printf(...)

/**
 * Interrupt Service Routine and DMA semaphore
 */
static xSemaphoreHandle spi_sem_dma;
static int __attribute__((__noinline__)) spi_DSR(avr32_spi_t* spi_dev) {
	portBASE_TYPE xTaskWoken = pdFALSE;
	printf("SPI ISR %08lX\r\n", spi_dev->sr);
	pdca_disable_interrupt_transfer_complete(PDC_CHANNEL_SPI_TX);
	pdca_disable_interrupt_transfer_complete(PDC_CHANNEL_SPI_RX);
	xSemaphoreGiveFromISR(spi_sem_dma, &xTaskWoken);
	return xTaskWoken;
}
static void __attribute__((__naked__)) spi0_ISR() {
	portENTER_SWITCHING_ISR();
	spi_DSR((avr32_spi_t*) AVR32_SPI0_ADDRESS);
	portEXIT_SWITCHING_ISR();
}

/**
 * Initialize SPI device
 * @param spi_dev A SPI module hardware configuration struct
 * @param spi_hw_index Hardware number (0 for SPI0, 1 for SPI1)
 */
int spi_init_dev(spi_dev_t * spi_dev) {

	int result;

	/* Input validation */
	if (spi_dev == NULL || spi_dev->index >= 2)
		return -1;

	switch (spi_dev->index) {
	case 0: {
		gpio_map_t spi_piomap = { { AVR32_SPI0_SCK_0_0_PIN,
				AVR32_SPI0_SCK_0_0_FUNCTION }, { AVR32_SPI0_MISO_0_0_PIN,
				AVR32_SPI0_MISO_0_0_FUNCTION }, { AVR32_SPI0_MOSI_0_0_PIN,
				AVR32_SPI0_MOSI_0_0_FUNCTION }, { AVR32_SPI0_NPCS_0_0_PIN,
				AVR32_SPI0_NPCS_0_0_FUNCTION }, { AVR32_SPI0_NPCS_1_0_PIN,
				AVR32_SPI0_NPCS_1_0_FUNCTION }, { AVR32_SPI0_NPCS_2_0_PIN,
				AVR32_SPI0_NPCS_2_0_FUNCTION }, { AVR32_SPI0_NPCS_3_1_PIN,
				AVR32_SPI0_NPCS_3_1_FUNCTION } };
		spi_dev->base = (avr32_spi_t*) AVR32_SPI0_ADDRESS;
		gpio_enable_module(spi_piomap, 7);
		break;
		}
	}

	/* Init master mode */
	spi_options_t options;
	options.modfdis = 1;

	result = at_spi_initMaster(spi_dev->base, &options);
	if (result != SPI_OK)
		return result;

	/* Start semaphore
	 * @todo Only one semaphore for two hardware devices! */
	if (spi_sem_dma == NULL) {
		vSemaphoreCreateBinary(spi_sem_dma);
		xSemaphoreTake(spi_sem_dma, 0);
	}

	/* Setup selection mode */
	result = at_spi_selectionMode(spi_dev->base, spi_dev->variable_ps, spi_dev->pcs_decode, 0);
	if (result != SPI_OK)
		return result;

	at_spi_enable(spi_dev->base);
#if 1
	/* Enable PDC */
	pdca_channel_options_t pdc_channel_rx;
	pdc_channel_rx.addr = 0;
	pdc_channel_rx.size = 0;
	pdc_channel_rx.r_addr = 0;
	pdc_channel_rx.r_size = 0;
	pdc_channel_rx.pid = AVR32_PDCA_PID_SPI0_RX;
	pdc_channel_rx.transfer_size = PDCA_TRANSFER_SIZE_BYTE;
	pdca_init_channel(PDC_CHANNEL_SPI_RX, &pdc_channel_rx);

	pdca_channel_options_t pdc_channel_tx;
	pdc_channel_tx.addr = 0;
	pdc_channel_tx.size = 0;
	pdc_channel_tx.r_addr = 0;
	pdc_channel_tx.r_size = 0;
	pdc_channel_tx.pid = AVR32_PDCA_PID_SPI0_TX;
	pdc_channel_tx.transfer_size = PDCA_TRANSFER_SIZE_BYTE;
	pdca_init_channel(PDC_CHANNEL_SPI_TX, &pdc_channel_tx);
#endif

	return result;

}

/**
 * @param spi_chip a chip configuration struct, this must be pre-configured with spi_dev and all options.
 */
int spi_setup_chip(spi_chip_t * spi_chip) {

	if (spi_chip == NULL || spi_chip->spi_dev == NULL)
		return -1;

	spi_options_t spi_opt;
	spi_opt.baudrate = spi_chip->baudrate;
	spi_opt.bits = spi_chip->bits;
	spi_opt.reg = spi_chip->reg;
	spi_opt.spck_delay = spi_chip->spck_delay;
	spi_opt.spi_mode = spi_chip->spi_mode;
	spi_opt.stay_act = spi_chip->stay_act;
	spi_opt.trans_delay = spi_chip->trans_delay;
	spi_opt.modfdis = 1;

	extern pm_freq_param_t clock_param;
	return at_spi_setupChipReg(spi_chip->spi_dev->base, &spi_opt, clock_param.pba_f);

}


/**
 * Send a byte/word via SPI
 * @param spi_chip The chip to send to
 * @param byte 8 bits to send
 */
void spi_write(spi_chip_t * spi_chip, uint16_t byte) {
	at_spi_selectChip(spi_chip->spi_dev->base, spi_chip->cs);
	at_spi_write(spi_chip->spi_dev->base, byte);
}

/**
 * Read a byte/word from SPI
 * @param spi_chip Chip to read from
 * @return bits received
 */
uint16_t spi_read(spi_chip_t * spi_chip) {
	uint16_t data;
	at_spi_selectChip(spi_chip->spi_dev->base, spi_chip->cs);
	at_spi_read(spi_chip->spi_dev->base, &data);
	return data;
}

/**
 * DMA based block transfer to and from SPI devices
 * For RX, a buffer full of 0xFF must be transmitted to create the clock
 * For TX, an empty RX buffer must be provided for dummy RX data.
 * This only works with fixed chip-select
 * @param outbuf pointer to TX buffer
 * @param inbuf  pointer to RX buffer
 * @param length Amount of bytes to transfer
 * @return return 0 if the SPI device was not ready, 1 otherwise.
 */
int spi_dma_transfer(spi_chip_t * spi_chip, uint8_t * outbuf, uint8_t * inbuf, uint32_t length) {

	printf("DMA!\r\n");

	unsigned int bytes_done = 0;


	/* DMA transfer only works with fixed chip select */
	if (spi_chip->spi_dev->variable_ps)
		return 0;

	/* Select chip */
	at_spi_selectChip(spi_chip->spi_dev->base, spi_chip->cs);

	/* Wait for SPI to become ready */
	avr32_spi_t * spi = spi_chip->spi_dev->base;
	unsigned int timeout = 1000000;
	while ((spi->sr & AVR32_SPI_SR_TDRE_MASK) == 0 && timeout > 0) {
		--timeout;
	}

	if (timeout == 0) {
		printf("SPI not ready\r\n");
		return 0;
	}

	/* Loop here if length is larger than 0xFFFF */
	while (bytes_done < length) {

		printf("SPI SR1 %08lX\r\n", spi->sr);

		/* Disable PDC and interrupt on SPI */
		pdca_disable(PDC_CHANNEL_SPI_TX);

		/* Enable PDC Interrupt */
		INTC_register_interrupt(spi0_ISR, AVR32_PDCA_IRQ_0 + PDC_CHANNEL_SPI_TX, 1);

		printf("SPI SR2 %08lX\r\n", spi->sr);
		printf("RPR %p\r\n", &inbuf);
		printf("TPR %p = %p\r\n", &outbuf, &outbuf[bytes_done]);

		/* Number of bytes to read - truncated to 64k */
		if ((length - bytes_done) > 0x0000FFFF) {
			if (inbuf != NULL)
				pdca_load_channel(PDC_CHANNEL_SPI_RX, &inbuf[bytes_done], 0x0000FFFF);
			pdca_load_channel(PDC_CHANNEL_SPI_TX, &outbuf[bytes_done], 0x0000FFFF);
			bytes_done += 0x0000FFFF;
		} else {
			if (inbuf != NULL)
				pdca_load_channel(PDC_CHANNEL_SPI_RX, &inbuf[bytes_done], length - bytes_done);
			pdca_load_channel(PDC_CHANNEL_SPI_TX, &outbuf[bytes_done], length - bytes_done);
			bytes_done = length;
		}

		printf("SPI SR3 %08lX\r\n", spi->sr);

		/* Enable PDC and interrupt on SPI */
		pdca_enable_interrupt_transfer_complete(PDC_CHANNEL_SPI_TX);
		pdca_enable(PDC_CHANNEL_SPI_TX);
		pdca_enable(PDC_CHANNEL_SPI_RX);

		printf("SPI SR4 %08lX\r\n", spi->sr);

		/* Wait for the DMA finish signal */
		if (xSemaphoreTake(spi_sem_dma, 1000) == pdFALSE) {
			printf("DMA timeout\r\n");
			/* Disable PDC and interrupt on SPI */
			pdca_disable(PDC_CHANNEL_SPI_TX);
			pdca_disable(PDC_CHANNEL_SPI_RX);
			return 0;
		}

		/* Disable PDC and interrupt on SPI */
		pdca_disable(PDC_CHANNEL_SPI_TX);
		pdca_disable(PDC_CHANNEL_SPI_RX);

	}

	return 1;

}
