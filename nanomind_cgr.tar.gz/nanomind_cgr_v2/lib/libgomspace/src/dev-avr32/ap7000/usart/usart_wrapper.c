/*
 * usart_wrapper.c
 *
 *  Created on: 21-08-2009
 *      Author: Administrator
 */

// Standard Includes
#include <inttypes.h>
#include <stdio.h>
#include <stdint.h>
#include <avr32/io.h>

// FreeRTOS
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

// Implement the public USART interface
#include <dev/usart.h>

// Using local driver functionality
#include "usart_atmel.h"
#include <dev/avr32/gpio.h>
#include <dev/avr32/intc.h>
#include <dev/ap7/cache.h>
#include <dev/ap7/addrspace.h>

#include <util/color_printf.h>

int vPortInISR(void);

/* Note: the buffer size must be a multiple of CONFIG_SYS_DCACHE_LINESZ and 
 * aligned to a cache line */
#define RX_PDC_BUF_SIZE	1024
//#define USART_NO_PDC

xSemaphoreHandle usart_semaphore = NULL;
xQueueHandle usart_rxqueue = NULL;
usart_callback_t rx_callback = NULL;
static volatile avr32_usart_t * usart = &AVR32_USART3;
static volatile uint8_t usart_rx_buf[2][RX_PDC_BUF_SIZE] __attribute__((aligned(CONFIG_SYS_DCACHE_LINESZ)));
static volatile uint32_t current_buf = 0;
static volatile uint32_t rx_size = 0;

__attribute__((__noinline__)) portBASE_TYPE usart_DSR() {
	static portBASE_TYPE xTaskWoken;
	xTaskWoken = pdFALSE;
	if (usart->CSR.rxrdy) {
		static char c;
		c = (char) usart->rhr;
		xQueueSendFromISR(usart_rxqueue, &c, &xTaskWoken);
	}
	return xTaskWoken;
}

__attribute__((__naked__)) void usart_ISR() {
	portENTER_SWITCHING_ISR1();
	usart_DSR();
	portEXIT_SWITCHING_ISR1();
}


__attribute__((__noinline__)) portBASE_TYPE usart_pdc_DSR() {

	static portBASE_TYPE xTaskWoken;
	static uint8_t i;
	xTaskWoken = pdFALSE;

	//dcache_invalidate_range(&usart_rx_buf[current_buf & 1][0], RX_PDC_BUF_SIZE);

	/* If no previous RX size was set, we received one byte */
	if (rx_size == 0)
		rx_size = 1;


	/* Process the incoming data (rx_size) */
	if(rx_callback != NULL) {
		//color_printf(COLOR_RED, "Size %u\r\n", rx_size);
		rx_callback((uint8_t *) uncached(&usart_rx_buf[current_buf & 1][0]), rx_size, &xTaskWoken);
	} else {
		for(i = 0; i < rx_size; i++) {
			xQueueSendFromISR(usart_rxqueue, (void *) uncached(&usart_rx_buf[current_buf & 1][i]), &xTaskWoken);
		}
	}

	//hex_dump(&usart_rx_buf[current_buf & 1][0], 64);
	//hex_dump(&usart_rx_buf[(current_buf+1) & 1][0], 64);

	/* Disable pdc, so it does not change while reading size */
	usart->PTCR.rxtdis = 1;

	/* We now set the reload size to full */
	usart->rnpr = (unsigned long) usart_rx_buf[current_buf & 1];
	usart->rncr = RX_PDC_BUF_SIZE;
	current_buf++;

	/* During the processing the main-buffer might be used, so readout the size and save it */
	rx_size = RX_PDC_BUF_SIZE - usart->rcr;

	/* If it was used, we would like to return to the interrupt */
	if (rx_size > 0) {
		//color_printf(COLOR_RED, "Size2 %u\r\n", rx_size);
		usart->rcr = 0;

	/* If it wasn't used, we would like to interrupt after next byte */
	} else {
		usart->rcr = 1;
		usart->PTCR.rxten = 1;
	}

	return xTaskWoken;
}

__attribute__((__naked__)) void usart_pdc_ISR() {
	portENTER_SWITCHING_ISR1();
	usart_pdc_DSR();
	portEXIT_SWITCHING_ISR1();
}

/**
 * Wrapper for the ATMEL USART driver init function
 * @param fcpu
 * @param usart_baud
 */
void usart_init(int handle, uint32_t fcpu, uint32_t usart_baud) {

	/* UART pin setup */
	gpio_enable_module_pin(AVR32_USART3_TXD_0_PIN, AVR32_USART3_TXD_0_FUNCTION);
	gpio_enable_module_pin(AVR32_USART3_RXD_0_PIN, AVR32_USART3_RXD_0_FUNCTION);

	/* UART channel setup */
	const usart_options_t usart_options = { usart_baud, 8,
			USART_NO_PARITY,USART_1_STOPBIT, USART_NORMAL_CHMODE};
	usart_init_rs232(&AVR32_USART3, &usart_options, fcpu);

	/* Create Queue */
	if (usart_rxqueue == NULL)
		usart_rxqueue = xQueueCreate(64, sizeof(char));

	if (usart_semaphore == NULL)
		usart_semaphore = xSemaphoreCreateMutex();

#ifdef USART_NO_PDC

	/* Enable Interrupt */
	INTC_register_interrupt((__int_handler ) &usart_ISR, AVR32_USART3_IRQ, 1);
	usart->IER.rxrdy = 1;

#else

	/* Enable PDC */
	usart->rpr = (unsigned int) usart_rx_buf[current_buf];
	usart->rcr = 1;
	usart->rnpr = (unsigned int) usart_rx_buf[(current_buf+1) & 0x01];
	usart->rncr = RX_PDC_BUF_SIZE;
	usart->PTCR.rxten = 1;
	usart->idr = 0xFFFFFFFF;
	usart->IER.endrx = 1;

	/* Enable Interrupt */
	INTC_register_interrupt((__int_handler ) &usart_pdc_ISR, AVR32_USART3_IRQ, 1);

#endif

}

void usart_set_callback(int handle, usart_callback_t callback) {
	rx_callback = callback;
}

void usart_insert(int handle, char c, void * pxTaskWoken) {
	if (pxTaskWoken == NULL)
		xQueueSendToBack(usart_rxqueue, &c, 0);
	else
		xQueueSendToBackFromISR(usart_rxqueue, &c, pxTaskWoken);
}

/**
 * Wrapper for ATMEL USART putchar function
 * @param c
 */
void usart_putc(int handle, char c) {
	usart_putchar(&AVR32_USART3, c);
}

/**
 * Put string. The use of a semaphore is a not optimal.
 * Look at the NanoMind DMA TX for at much better solution.
 * @param str String to send
 * @param length Length of string
 */
void usart_putstr(int handle, char * str, int length) {

	int i;
	int in_isr = vPortInISR();

	if (!in_isr)
		if (xSemaphoreTake(usart_semaphore, 1 * configTICK_RATE_HZ) != pdTRUE)
			return;

	for (i = 0; i < length; i++)
		usart_putc(handle, str[i]);

	if (!in_isr)
		xSemaphoreGive(usart_semaphore);

}

/**
 * Return next char in queue
 */
char usart_getc(int handle) {
	char c;
	xQueueReceive(usart_rxqueue, &c, portMAX_DELAY);
	return c;
}

int usart_messages_waiting(int handle) {
	return uxQueueMessagesWaiting(usart_rxqueue);
}
