/**
 * WDT driver for AP7001
 *
 * @author Johan De Claville Christiansen
 * Copyright 2010 GomSpace ApS. All rights reserved.
 */

#include <avr32/io.h>
#include <dev/wdt.h>

void wdt_init(void) {
	AVR32_WDT.ctrl = 0x55000F00;
	AVR32_WDT.ctrl = 0xAA000F00;
}

void wdt_clear(void) {
	AVR32_WDT.clr = 1;
	AVR32_RTC.CTRL.pclr = 1;
}

void wdt_disable(void) {
	AVR32_WDT.ctrl = 0x55000F00;
	AVR32_WDT.ctrl = 0xAA000F00;
}

void wdt_enable(void) {
	AVR32_WDT.ctrl = 0x55000F01;
	AVR32_WDT.ctrl = 0xAA000F01;
}
