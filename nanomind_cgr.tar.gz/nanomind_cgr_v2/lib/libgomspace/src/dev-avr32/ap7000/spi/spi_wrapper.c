/*
 * spi_wrapper.c
 *
 *  Created on: 27-11-2009
 *      Author: Administrator
 */

#include <stdio.h>
#include <stdint.h>
#include <avr32/io.h>

#include <dev/avr32/intc.h>
#include <dev/ap7/pio.h>
#include <dev/ap7/cache.h>
#include <dev/ap7/pm_at32ap7000.h>
#include <dev/spi.h>

#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <freertos/task.h>

#include "spi_at32ap7000.h"

/**
 * Interrupt Service Routine and DMA semaphore
 */
static xSemaphoreHandle spi_sem_dma;
static int __attribute__((__noinline__)) spi_DSR(avr32_spi_t* spi_dev) {
	portBASE_TYPE xTaskWoken = pdFALSE;
	//printf("SPI ISR %08X\r\n", spi_dev->SR);
	spi_dev->IDR.endtx = 1;
	xSemaphoreGiveFromISR(spi_sem_dma, &xTaskWoken);
	return xTaskWoken;
}
static void __attribute__((__naked__)) spi0_ISR() {
	portENTER_SWITCHING_ISR1();
	spi_DSR((avr32_spi_t*) AVR32_SPI0_ADDRESS);
	portEXIT_SWITCHING_ISR1();
}
static void __attribute__((__naked__)) spi1_ISR() {
	portENTER_SWITCHING_ISR1();
	spi_DSR((avr32_spi_t*) AVR32_SPI1_ADDRESS);
	portEXIT_SWITCHING_ISR1();
}

/**
 * Initialize SPI device
 * @param spi_dev A SPI module hardware configuration struct
 * @param spi_hw_index Hardware number (0 for SPI0, 1 for SPI1)
 */
int spi_init_dev(spi_dev_t * spi_dev) {

	/* Input validation */
	if (spi_dev == NULL || spi_dev->index >= 2)
		return 0;

	switch (spi_dev->index) {
	case 0: {
		gpio_map_t spi_piomap = { { AVR32_SPI0_SCK_0_PIN,
				AVR32_SPI0_SCK_0_FUNCTION }, { AVR32_SPI0_MISO_0_PIN,
				AVR32_SPI0_MISO_0_FUNCTION }, { AVR32_SPI0_MOSI_0_PIN,
				AVR32_SPI0_MOSI_0_FUNCTION }, { AVR32_SPI0_NPCS_0_PIN,
				AVR32_SPI0_NPCS_0_FUNCTION }, { AVR32_SPI0_NPCS_1_PIN,
				AVR32_SPI0_NPCS_1_FUNCTION }, { AVR32_SPI0_NPCS_2_PIN,
				AVR32_SPI0_NPCS_2_FUNCTION }, { AVR32_SPI0_NPCS_3_PIN,
				AVR32_SPI0_NPCS_3_FUNCTION } };
		spi_dev->base = (avr32_spi_t*) AVR32_SPI0_ADDRESS;
		INTC_register_interrupt(&spi0_ISR, AVR32_SPI0_IRQ, AVR32_INTC_INT1);
		gpio_enable_module(spi_piomap, 7);
		break;
		}
	case 1: {
		gpio_map_t spi_piomap = { { AVR32_SPI1_SCK_0_PIN,
				AVR32_SPI1_SCK_0_FUNCTION }, { AVR32_SPI1_MISO_0_PIN,
				AVR32_SPI1_MISO_0_FUNCTION }, { AVR32_SPI1_MOSI_0_PIN,
				AVR32_SPI1_MOSI_0_FUNCTION }, { AVR32_SPI1_NPCS_0_PIN,
				AVR32_SPI1_NPCS_0_FUNCTION }, { AVR32_SPI1_NPCS_1_PIN,
				AVR32_SPI1_NPCS_1_FUNCTION }, { AVR32_SPI1_NPCS_2_PIN,
				AVR32_SPI1_NPCS_2_FUNCTION }, { AVR32_SPI1_NPCS_3_PIN,
				AVR32_SPI1_NPCS_3_FUNCTION } };
		spi_dev->base = (avr32_spi_t*) AVR32_SPI1_ADDRESS;
		INTC_register_interrupt(&spi1_ISR, AVR32_SPI1_IRQ, AVR32_INTC_INT1);
		gpio_enable_module(spi_piomap, 7);
		break;
		}
	}

	/* Init master mode */
	spi_options_t options;
	options.modfdis = 1;
	options.fdiv = spi_dev->fdiv;
	at_spi_initMaster(spi_dev->base, &options);

	/* Start semaphore
	 * @todo Only one semaphore for two hardware devices! */
	if (spi_sem_dma == NULL) {
		vSemaphoreCreateBinary(spi_sem_dma);
		xSemaphoreTake(spi_sem_dma, 0);
	}

	/* Setup selection mode */
	at_spi_selectionMode(spi_dev->base, spi_dev->variable_ps, spi_dev->pcs_decode, 0);
	at_spi_enable(spi_dev->base);

	return 1;

}

/**
 * @param spi_chip a chip configuration struct, this must be pre-configured with spi_dev and all options.
 */
int spi_setup_chip(spi_chip_t * spi_chip) {

	if (spi_chip == NULL || spi_chip->spi_dev == NULL)
		return 0;

	spi_options_t spi_opt;
	spi_opt.baudrate = spi_chip->baudrate;
	spi_opt.bits = spi_chip->bits;
	spi_opt.reg = spi_chip->reg;
	spi_opt.spck_delay = spi_chip->spck_delay;
	spi_opt.spi_mode = spi_chip->spi_mode;
	spi_opt.stay_act = spi_chip->stay_act;
	spi_opt.trans_delay = spi_chip->trans_delay;
	spi_opt.modfdis = 1;

	at_spi_setupChipReg(spi_chip->spi_dev->base, &spi_opt, pm_read_module_freq_hz(PM_PBA_SPI0));

	return 1;

}


/**
 * Send a byte/word via SPI
 * @param spi_chip The chip to send to
 * @param byte 8 bits to send
 */
void spi_write(spi_chip_t * spi_chip, uint16_t byte) {
	at_spi_selectChip(spi_chip->spi_dev->base, spi_chip->cs);
	at_spi_write(spi_chip->spi_dev->base, byte);
}

/**
 * Read a byte/word from SPI
 * @param spi_chip Chip to read from
 * @return bits received
 */
uint16_t spi_read(spi_chip_t * spi_chip) {
	uint16_t data;
	at_spi_selectChip(spi_chip->spi_dev->base, spi_chip->cs);
	at_spi_read(spi_chip->spi_dev->base, &data);
	return data;
}

/**
 * DMA based block transfer to and from SPI devices
 * For RX, a buffer full of 0xFF must be transmitted to create the clock
 * For TX, an empty RX buffer must be provided for dummy RX data.
 * This only works with fixed chip-select
 * @param outbuf pointer to TX buffer
 * @param inbuf  pointer to RX buffer
 * @param length Amount of bytes to transfer
 * @return return 0 if the SPI device was not ready, 1 otherwise.
 */
int spi_dma_transfer(spi_chip_t * spi_chip, uint8_t * outbuf, uint8_t * inbuf, uint32_t length) {

	int bytes_done = 0;

	volatile uint32_t * rpr = (uint32_t *) (spi_chip->spi_dev->base + 0x100);
	volatile uint32_t * rcr = (uint32_t *) (spi_chip->spi_dev->base + 0x104);
	volatile uint32_t * tpr = (uint32_t *) (spi_chip->spi_dev->base + 0x108);
	volatile uint32_t * tcr = (uint32_t *) (spi_chip->spi_dev->base + 0x10C);
	volatile uint32_t * ptcr = (uint32_t *) (spi_chip->spi_dev->base + 0x120);

	/* DMA transfer only works with fixed chip select */
	if (spi_chip->spi_dev->variable_ps)
		return 0;

	/* Select chip */
	at_spi_selectChip(spi_chip->spi_dev->base, spi_chip->cs);

	/* Wait for SPI to become ready */
	//if (!spi_busy_wait())
	//	return 0;
	avr32_spi_t * spi = spi_chip->spi_dev->base;
	unsigned int timeout = 1000000;
	while ((spi->sr & AVR32_SPI_SR_TDRE_MASK) == 0 && timeout > 0) {
		--timeout;
	}

	if (timeout == 0) {
		printf("SPI not ready\r\n");
		return 0;
	}

	/* Flush cache lines before transfer */
	dcache_flush_range(outbuf, length);

	/* Loop here if length is larger than 0xFFFF */
	while (bytes_done < length) {

		//printf("SPI SR1 %08X\r\n", spi->SR);

		/* Disable PDC and interrupt on SPI */
		((avr32_spi_t *)spi_chip->spi_dev->base)->IDR.endtx = 1;
		*ptcr = ((1 << 9) | (1 << 1));

		//printf("SPI SR2 %08X\r\n", spi->SR);

		/* Start PDC Transfer */
		if (inbuf != NULL)
			*rpr = (uint32_t) &inbuf[bytes_done];
		*tpr = (uint32_t) &outbuf[bytes_done];

		//printf("RPR %p = %p\r\n", *rpr, inbuf);
		//printf("TPR %p = %p = %p\r\n", *tpr, outbuf, (uint32_t) &outbuf[bytes_done]);

		/* Number of bytes to read - truncated to 64k */
		if ((length - bytes_done) > 0x0000FFFF) {
			if (inbuf != NULL)
				*rcr = 0x0000FFFF;
			*tcr = 0x0000FFFF;
			bytes_done += 0x0000FFFF;
		} else {
			if (inbuf != NULL)
				*rcr = length - bytes_done;
			*tcr = length - bytes_done;
			bytes_done = length;
		}

		//printf("RCR %x VAL %u\r\n", rcr, *rcr);
		//printf("TCR %x VAL %u\r\n", tcr, *tcr);

		//printf("SPI SR3 %08X\r\n", spi->SR);

		/* Enable PDC and interrupt on SPI */
		((avr32_spi_t *)spi_chip->spi_dev->base)->IER.endtx = 1;
		*ptcr = (1 << 8) | (1 << 0);

		//printf("SPI SR4 %08X\r\n", spi->SR);

		/* Wait for the DMA finish signal */
		if (xSemaphoreTake(spi_sem_dma, 1 * configTICK_RATE_HZ) == pdFALSE) {
			printf("DMA timeout\r\n");
			/* Disable PDC and interrupt on SPI */
			((avr32_spi_t *)spi_chip->spi_dev->base)->IDR.endtx = 1;
			*ptcr = ((1 << 9) | (1 << 1));
			return 0;
		}

		/* Disable PDC and interrupt on SPI */
		((avr32_spi_t *)spi_chip->spi_dev->base)->IDR.endtx = 1;
		*ptcr = ((1 << 9) | (1 << 1));


	}

	/* Invalidate cache lines */
	dcache_invalidate_range(inbuf, length);

	return 1;

}
