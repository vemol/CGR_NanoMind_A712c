#ifndef _IS42S32800B_H_
#define _IS42S32800B_H_

#define SDRAM_CLOCK 120000000
#define SDRAM_CYCLE_TIME_NS 9

/*
These values are device specific. Consult the datasheet for
the given device for more information
*/

/*!
 * The number of columns for this sdram.
 */
// number of cols = 512  ->  9 col bits
#define SDRAM_COL_BITS  9

/*!
 * The number of rows for this sdram.
 */
// number of rows = 4096 -> 12 row bits
#define SDRAM_ROW_BITS  12

/*!
 * The number of banks for this sdram.
 */
// number of banks = 4   ->  2 bank bits
#define SDRAM_BANK_BITS 2


/*!
 * The refresh rate. NOTE: This is dependant on the clock frequency
 */
// Refresh rate
// Use 15.6 uS = 15600 ns.
// With cpu hz 20 MHz = 50 ns clock cycle :
// Refresh rate = 15600 ns / 50 ns = 312 clock cycles
// Generic formula for chip (156 * (CPU_HZ / 1000) ) / 10000
#define SDRAM_TR (15600 / SDRAM_CYCLE_TIME_NS)
#define SDRAM_TR_NS 15600

/*!
 * The CAS latency for this sdram.
 * Min clock period for
 * CAS2: 10ns (max 100 MHz)
 * CAS3: 7ns (max 140 MHZ)
 */
#define SDRAM_CAS 3
#define SDRAM_CAS_2_MAX_SPEED 100000000

/*!
 * The write recovery time. NOTE: This setting is dependant on the clock frequency
 * Min 2 clks
 */
#define SDRAM_TWR 2

/*!
 * Minimal ACTIVE to ACTIVE command period. NOTE: This setting is dependant on the clock frequency
 * Min 70 ns
 */
#define SDRAM_TRC_MIN_NS 70
#define SDRAM_TRC ((SDRAM_TRC_MIN_NS / SDRAM_CYCLE_TIME_NS) + 1)

/*!
 * Minimal PRECHARGE command period. NOTE: This setting is dependant on the clock frequency
 * Min 20 ns
 */
#define SDRAM_TRP_MIN_NS 20
#define SDRAM_TRP ((SDRAM_TRP_MIN_NS / SDRAM_CYCLE_TIME_NS) + 1)

/*!
 * Minimal ACTIVE to READ or WRITE delay. NOTE: This setting is dependant on the clock frequency
 * Min 20 ns
 */
#define SDRAM_TRCD_MIN_NS 20
#define SDRAM_TRCD ((SDRAM_TRCD_MIN_NS / SDRAM_CYCLE_TIME_NS) + 1)

/*!
 * Minimal ACTIVE to PRECHARGE command. NOTE: This setting is dependant on the clock frequency.
 * Min 45 ns
 */
#define SDRAM_TRAS_MIN_NS 45
#define SDRAM_TRAS ((SDRAM_TRC_MIN_NS / SDRAM_CYCLE_TIME_NS) + 1)

/*!
 *Minimal exit SELF REFRESH to ACTIVE command. NOTE: This setting is dependant on the clock frequency
 */
#define SDRAM_TXSR SDRAM_TRCD
#define SDRAM_TXSR_MIN_NS SDRAM_TRCD_MIN_NS

//! The minimal number of AUTO REFRESH commands required during initialization for this SDRAM.
#define SDRAM_INIT_AUTO_REFRESH_COUNT 2

//! The minimal mode register delay time for this SDRAM.
//! LOAD MODE REGISTER command to ACTIVE or REFRESH command delay.
//! Unit: tCK (SDRAM cycle period).
#define SDRAM_TMRD                      2

//! The minimal stable-clock initialization delay for this SDRAM.
//! Unit: us.
#define SDRAM_STABLE_CLOCK_INIT_DELAY   200

#endif
