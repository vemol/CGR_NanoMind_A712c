/*
 * idle.c
 *
 *  Created on: 22-08-2009
 *      Author: Administrator
 */

#include <avr32/io.h>
#include <stdio.h>

#include <dev/avr32/compiler.h>

/*! \brief Sets the MCU in the specified sleep mode.
 *
 * \param mode Sleep mode:
 *   \arg \c AVR32_PM_SMODE_IDLE: Idle;
 *   \arg \c AVR32_PM_SMODE_FROZEN: Frozen;
 *   \arg \c AVR32_PM_SMODE_STANDBY: Standby;
 *   \arg \c AVR32_PM_SMODE_STOP: Stop;
 *   \arg \c AVR32_PM_SMODE_DEEP_STOP: DeepStop;
 *   \arg \c AVR32_PM_SMODE_STATIC: Static.
 */

static int do_sleep = 1;

void vApplicationIdleHook(void) {
	if (do_sleep) {
		__asm__ __volatile__ ("sleep 0");
	}
}

void idle_sleep_enable(void) {
	do_sleep = 1;
}

void idle_sleep_disable(void) {
	do_sleep = 0;
}
