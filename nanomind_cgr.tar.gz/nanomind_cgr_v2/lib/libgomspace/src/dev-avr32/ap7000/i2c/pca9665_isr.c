/**
 * @file pca9665_isr.c
 * Low level ISR functions for PCA9665 device on NanoCam boards
 *
 * @author Johan De Claville Christiansen
 * Copyright 2011 GomSpace ApS. All rights reserved.
 */

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <dev/cpu.h>
#include <util/color_printf.h>
#include <util/driver_debug.h>

#include <avr32/ap7001.h>
#include <dev/avr32/intc.h>
#include <dev/ap7/gpio.h>
#include <dev/ap7/pm_at32ap7000.h>

#include "../../../dev/pca9665/pca9665.h"

/* Number of devices present on board */
const int pca9665_device_count = 1;

/* Setup of each device */
pca9665_device_object_t device[1] = {
	{
		.base = (uint8_t *)(0x0C000000 | 0xA0000000),
		.is_initialised = 0,
		.is_busy = 0,
		.mode = DEVICE_MODE_M_T,
		.callback = NULL,
		.tx.frame = NULL,
		.tx.queue = NULL,
		.rx.queue = NULL,
	}
};

__attribute__((__noinline__)) portBASE_TYPE pca9665_DSR(void) {
	volatile avr32_eic_t * eic = &AVR32_EIC;
	static portBASE_TYPE task_woken;
	//printf("I\r\n");
	task_woken = pdFALSE;
	pca9665_dsr(&task_woken);

	eic->ICR.int0 = 1;
	return task_woken;
}

__attribute__((naked)) void pca9665_ISR(void) {
	portENTER_SWITCHING_ISR1();
	pca9665_DSR();
	portEXIT_SWITCHING_ISR1();
}

void pca9665_isr_init(void) {

	/**
	 * WARNING:
	 * The order of initialisation is important since the SMC must be given
	 * a few moments in order to be stable, before calling the PCA9665.
	 */

	/**
	 * AVR32_EBI_CS3_ADDRESS = 0x0C000000
	 * #define AVR32_SMC_ADDRESS                  0xFFF03400
	 * #define AVR32_SMC                          (*((volatile avr32_smc_t*)AVR32_SMC_ADDRESS))
	 */
	volatile avr32_smc_t * smc = &AVR32_SMC;
	volatile avr32_hmatrix_t *hmatrix = &AVR32_HMATRIX;

	#define SMC_BASE	(0xFFF03400)
	#define SMC_CS3		(SMC_BASE + (0x10 * 3))
	#define SMC_3_SETUP	((volatile uint32_t *) (SMC_CS3 + 0x0))
	#define SMC_3_PULSE	((volatile uint32_t *) (SMC_CS3 + 0x4))
	#define SMC_3_CYCLE	((volatile uint32_t *) (SMC_CS3 + 0x8))
	#define SMC_3_MODE	((volatile uint32_t *) (SMC_CS3 + 0xC))

#if 0
	printf("Setting up Static Memory Controller\r\n");
	printf("Version: %u.%u\r\n", smc->VERSION.version, smc->VERSION.variant);

	printf("Chip Select 3 [0x%08X]\r\n", AVR32_EBI_CS3_ADDRESS);
	printf("SETUP: %08lX\r\n", smc->cs[3].setup);
	printf("PULSE: %08lX\r\n", smc->cs[3].pulse);
	printf("CYCLE: %08lX\r\n", smc->cs[3].cycle);
	printf("MODE : %08lX\r\n", smc->cs[3].mode);
	printf("HMATRIX_SFR4: %08lX\r\n", hmatrix->sfr[4]);

	printf("OWN DEFINES:\r\n");
	printf("SETUP: %08lX\r\n", *SMC_3_SETUP);
	printf("PULSE: %08lX\r\n", *SMC_3_PULSE);
	printf("CYCLE: %08lX\r\n", *SMC_3_CYCLE);
	printf("MODE : %08lX\r\n", *SMC_3_MODE);
#endif

	/* Enable SRAM mode for CS3 in the BAMBI mux */
	hmatrix->sfr[4] &= ~0x00000008;		// SRAM mode for CS3
	hmatrix->sfr[4] |= 0x00000100;		// Do NOT enable internal pullup? (SDRAM sets this)

	int setup = 40.0E-9 / (1.0/pm_read_module_freq_hz(PM_HSB_HEBI));
	int pulse = 80.0E-9 / (1.0/pm_read_module_freq_hz(PM_HSB_HEBI));
	int hold  = 40.0E-9 / (1.0/pm_read_module_freq_hz(PM_HSB_HEBI));
	int cycle = (setup + pulse + hold);

#if 0
	printf("Setup clks: %u\r\n", setup);
	printf("Pulse clks: %u\r\n", pulse);
	printf("Hold  clks: %u\r\n", hold);
	printf("Cycle clks: %u\r\n", cycle);
#endif

	smc->cs[3].SETUP.ncs_rd_setup = setup;
	smc->cs[3].SETUP.ncs_wr_setup = setup;
	smc->cs[3].SETUP.nrd_setup = setup;
	smc->cs[3].SETUP.nwe_setup = setup;

	smc->cs[3].PULSE.ncs_rd_pulse = pulse;
	smc->cs[3].PULSE.ncs_wr_pulse= pulse;
	smc->cs[3].PULSE.nrd_pulse = pulse;
	smc->cs[3].PULSE.nwe_pulse = pulse;

	smc->cs[3].CYCLE.nrd_cycle = cycle;
	smc->cs[3].CYCLE.nwe_cycle = cycle;

	smc->cs[3].MODE.read_mode = 1; //AVR32_SMC_MODE3_READ_MODE_NRD_CONTROLLED;
	smc->cs[3].MODE.write_mode = 1; //AVR32_SMC_MODE3_WRITE_MODE_NWE_CONTROLLED;
	smc->cs[3].MODE.exnw_mode = 0; //AVR32_SMC_MODE3_EXNW_MODE_DISABLED;
	smc->cs[3].MODE.dbw = AVR32_SMC_MODE3_DBW_8_BITS;
	smc->cs[3].MODE.tdf_cycles = 0;
	smc->cs[3].MODE.tdf_mode = 0;
	smc->cs[3].MODE.pmen = 0;

#if 0
	printf("SETUP: %08lX\r\n", smc->cs[3].setup);
	printf("PULSE: %08lX\r\n", smc->cs[3].pulse);
	printf("CYCLE: %08lX\r\n", smc->cs[3].cycle);
	printf("MODE : %08lX\r\n", smc->cs[3].mode);
	printf("HMATRIX_SFR4: %08lX\r\n", hmatrix->sfr[4]);

	printf("OWN DEFINES:\r\n");
	printf("SETUP: %08lX\r\n", *SMC_3_SETUP);
	printf("PULSE: %08lX\r\n", *SMC_3_PULSE);
	printf("CYCLE: %08lX\r\n", *SMC_3_CYCLE);
	printf("MODE : %08lX\r\n", *SMC_3_MODE);

	printf("OWN: %p, ATMEL %p\r\n", SMC_3_SETUP, &(smc->cs[3].setup));
#endif

	//driver_debug_set(DEBUG_I2C, 1);

	/* Enable Interrupt */
	gpio_enable_module_pin(AVR32_PIOB_P_25_PIN, 0);
	INTC_register_interrupt(&pca9665_ISR, AVR32_EIC_IRQ_0, AVR32_INTC_INT1);
	volatile avr32_eic_t * eic = &AVR32_EIC;

	//eic->MODE.int0 = 0;		// Mode = Edge triggered
	//eic->EDGE.int0 = 0;		// Edge = Falling edge

	eic->MODE.int0 = 1;			// Level Triggered
	eic->LEVEL.int0 = 0;		// Trigger low level

	eic->ICR.int0 = 1;			// Clear interrupt
	eic->IER.int0 = 1;			// Enable External ISR0

}

