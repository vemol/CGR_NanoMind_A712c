/*
 * cpu.c
 *
 *  Created on: 22-08-2009
 *      Author: Administrator
 */

#include <stdio.h>
#include <dev/cpu.h>
#include <avr32/ap7001.h>
#include <freertos/FreeRTOS.h>

void cpu_reset(void) {
#if 0
	portDISABLE_INTERRUPTS();
	AVR32_WDT.ctrl = 0x55000F01;
	AVR32_WDT.ctrl = 0xAA000F01;
	printf("Reset waiting for WDT\r\n");
#else
	/* This will reset the CPU core, caches, MMU and all internal busses */
	__builtin_mtdr(8, 1 << 13);	/* set DC:DBE */
	__builtin_mtdr(8, 1 << 30);	/* set DC:RES */

	/* Flush the pipeline before we declare it a failure */
	asm volatile("sub   pc, pc, -4");
#endif

	while(1);
}
