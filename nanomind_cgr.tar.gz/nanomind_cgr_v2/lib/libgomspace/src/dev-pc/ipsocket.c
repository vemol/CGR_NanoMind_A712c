/*
 * ipsocket.c
 *
 *  Created on: Sep 24, 2010
 *      Author: Martin Dam
 */

#include <stdio.h>

#include <dev/x86/ipsocket.h>

/**
 * Create a internet protocol socket
 */
int csp_ip_socket(int family, int socket_type, int protocol) {
	int sock = socket(family, socket_type, protocol);
	/* Enable address reuse */
	int on = 1;
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	return sock;
}
/**
 * Connect to a ip and port
 */
int csp_ip_connect(int sock, int family, char *ip, int port, char * src_ip) {

	if (src_ip != NULL && strlen(src_ip) > 7 && strlen(src_ip) <= 15) {
		/* Set source address */
		struct sockaddr_in ClientAddr; 		/* Local address */
		memset(&ClientAddr, 0, sizeof(ClientAddr));   /* Zero out structure */
		ClientAddr.sin_family = family;                /* Internet address family */
		ClientAddr.sin_addr.s_addr = inet_addr(src_ip); /*Use the given IP address*/ //htonl(INADDR_ANY); /* Any incoming interface */
		bind(sock, (struct sockaddr *) &ClientAddr, sizeof(ClientAddr));
	}

	/* Construct the server address structure */
	struct sockaddr_in ServAddr; 		/* Server address */
	memset(&ServAddr, 0, sizeof(ServAddr));     	/* Zero out structure */
	ServAddr.sin_family      = family;             /* Internet address family */
	ServAddr.sin_addr.s_addr = inet_addr(ip);   /* Server IP address */
	ServAddr.sin_port        = htons(port); 	/* Server port */

	return connect(sock, (struct sockaddr *) &ServAddr, sizeof(ServAddr));
}
/**
 * Send data on created and connection socket
 */
int csp_ip_send(int sock, __const void *__buf, size_t __n, int __flags) {
	return send(sock, (unsigned char *)__buf, __n, __flags);
}

int csp_ip_bind(int sock, int family, int port, char * ip) {

	struct sockaddr_in ServAddr; 		/* Local address */

	/* Construct local address structure */
	memset(&ServAddr, 0, sizeof(ServAddr));   /* Zero out structure */
	ServAddr.sin_family = family;                /* Internet address family */
	ServAddr.sin_addr.s_addr = inet_addr(ip); /*Use the given IP address*/ //htonl(INADDR_ANY); /* Any incoming interface */
	ServAddr.sin_port = htons(port);      	/* Local port */

	return bind(sock, (struct sockaddr *) &ServAddr, sizeof(ServAddr));
}
int csp_ip_listen (int sock, int size) {
	return listen(sock, size);
}

int csp_ip_accept(int sock, struct sockaddr * buf, unsigned int *size) {
	return accept(sock, (struct sockaddr *)buf, size);
}
int csp_ip_recv (int sock, __const void *buf, int __n, int __flags) {
	return recv(sock, (void *)buf, __n, __flags);
}

int csp_ip_recvfrom(int __fd, void *__restrict __buf, size_t __n, int __flags, __SOCKADDR_ARG __addr, int * __addr_len) {
	return recvfrom(__fd, __buf, __n, __flags, __addr, (socklen_t *__restrict)__addr_len);
}
int csp_ip_sendto (int __fd, __const void *__buf, size_t __n, int __flags, __CONST_SOCKADDR_ARG __addr, socklen_t __addr_len) {
	return sendto(__fd, __buf, __n, __flags, __addr, __addr_len);
}
int csp_ip_close (int sock) {
	return close(sock);
}
