/*
 * cmd_dfl.c
 *
 *  Created on: Sep 17, 2012
 *      Author: johan
 */

#include <conf_gomspace.h>

#include <stdlib.h>
#include <string.h>

#ifdef __linux__
#include <unistd.h>
#include <termios.h>
#endif

#include <dev/usart.h>
#include <util/console.h>
#include <util/hexdump.h>
#include <util/driver_debug.h>
#include <util/log.h>
#include "command/command.h"

#ifndef __linux__
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <dev/cpu.h>
#endif

int help_handler(struct command_context * context) {
	command_help(command_args(context));
	return CMD_ERROR_NONE;
}

int sleep_handler(struct command_context * context) {
	unsigned long sleep_ms;

	if (context->argc != 2)
		return CMD_ERROR_SYNTAX;

	sleep_ms = atoi(context->argv[1]);

	if (sleep_ms < 1)
		return CMD_ERROR_SYNTAX;

#ifndef __linux__
	vTaskDelay(sleep_ms * (configTICK_RATE_HZ / 1000.0));
#else
	usleep(sleep_ms*1000);
#endif

	return CMD_ERROR_NONE;
}

int watch_handler(struct command_context * context) {

	int sleep_ms = atoi(context->argv[1]);

	if (sleep_ms < 1)
		return CMD_ERROR_SYNTAX;

	printf("Execution delay: %d\r\n", sleep_ms);

	char * new_command = strstr(command_args(context), " ");

	if (new_command == NULL)
		return CMD_ERROR_SYNTAX;
	else
		new_command = new_command + 1;

	printf("Command: %s\r\n", new_command);

	while(1) {

		if (usart_messages_waiting(USART_CONSOLE))
			break;

		command_run(new_command);

#ifndef __linux__
		vTaskDelay(sleep_ms * (configTICK_RATE_HZ / 1000.0));
#else
		usleep(sleep_ms*1000);
#endif

	}

	return CMD_ERROR_NONE;

}

#ifndef __linux__
int cpu_reset_handler(struct command_context * context) {
	if (cpu_set_reset_cause)
		cpu_set_reset_cause(CPU_RESET_USER);
	cpu_reset();
	return CMD_ERROR_NONE;
}

int ps_handler(struct command_context * context) {
	signed char printbuffer[384];
	vTaskList(printbuffer);
	printf("%s", printbuffer);
	return CMD_ERROR_NONE;
}

int peek_handler(struct command_context * ctx) {

	unsigned int addr, len;

	if (ctx->argc != 3)
		return CMD_ERROR_SYNTAX;
	if (sscanf(ctx->argv[1], "%x", &addr) != 1)
		return CMD_ERROR_SYNTAX;
	if (sscanf(ctx->argv[2], "%u", &len) != 1)
		return CMD_ERROR_SYNTAX;

	printf("Dumping mem from addr %u len %u\r\n", addr, len);
	hex_dump((void *) addr, len);

	return CMD_ERROR_NONE;
}

int poke_handler(struct command_context * ctx) {

	unsigned int addr, value;

	if (ctx->argc != 3)
		return CMD_ERROR_SYNTAX;
	if (sscanf(ctx->argv[1], "%x", &addr) != 1)
		return CMD_ERROR_SYNTAX;
	if (sscanf(ctx->argv[2], "%x", &value) != 1)
		return CMD_ERROR_SYNTAX;

	printf("Setting addr 0x08%x = 0x08%x\r\n", addr, value);

	/* Dangerous */
	*(unsigned int *) addr = value;

	return CMD_ERROR_NONE;
}

#if configGENERATE_RUN_TIME_STATS
int stats_handler(struct command_context *ctx) {
	signed char buffer[512];
	vTaskGetRunTimeStats(buffer);
	printf("%s\r\n", buffer);
	return CMD_ERROR_NONE;
}
#endif
#else
int exit_handler(struct command_context * context) {
	exit(EXIT_SUCCESS);
	return CMD_ERROR_NONE;
}
#endif

command_t __root_command cmd_dfl[] = {
	{
		.name = "help",
		.help = "Show help",
		.usage = "<command>",
		.handler = help_handler,
	},{
		.name = "sleep",
		.help = "Sleep X ms",
		.usage = "<time>",
		.handler = sleep_handler,
	},{
		.name = "watch",
		.help = "Run cmd at intervals, abort with key",
		.usage = "<n> <command>",
		.handler = watch_handler,
	},
#ifndef __linux__
	{
		.name = "reset",
		.help = "Reset now",
		.handler = cpu_reset_handler,
	},{
#if defined(CONFIG_DRIVER_DEBUG)
		.name = "tdebug",
		.help = "Toggle driver debug",
		.usage = "<level>",
		.handler = cmd_driver_debug_toggle,
	},{
#endif
		.name = "ps",
		.help = "List tasks",
		.handler = ps_handler,
	},{
		.name = "peek",
		.help = "Dump memory",
		.usage = "<addr> <len>",
		.handler = peek_handler,
	},{
		.name = "poke",
		.help = "Change memory",
		.usage = "<addr> <value>",
		.handler = poke_handler,
	},
#if configGENERATE_RUN_TIME_STATS
	{
		.name = "stats",
		.help = "Get runtime stats",
		.handler = stats_handler,
	},
#endif
#else
	{
		.name = "exit",
		.help = "Exit program",
		.handler = exit_handler,
	},
#endif
};

void cmd_dfl_setup(void) {
	command_register(cmd_dfl);
}
