/**
 * Hash functions
 *
 * Copyright 2010 GomSpace ApS. All rights reserved.
 */

#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <assert.h>

#include <util/hash.h>
#include <util/log.h>

/**
 * Jenkins's one-at-a-time hash is adapted here from a WWW page by Bob Jenkins,[1]
 * which is an expanded version of his Dr. Dobbs article.[2]
 *
 * [1] http://en.wikipedia.org/wiki/Jenkins_hash_function#cite_note-dobbsx-0
 * [2] http://en.wikipedia.org/wiki/Jenkins_hash_function#cite_note-dobbs-1
 */
uint32_t hash_jenkins(const char *key, size_t len) {
	uint32_t hash, i;
	for (hash = i = 0; i < len; ++i) {
		hash += key[i];
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash;
}

/**
 * Initialise a hash table
 * @param nr_bits number of bits used for indexing (length = 2^n), max 16
 * @return hash table handle
 */
hash_table_t * hash_table_init(unsigned int nr_bits) {

	if (nr_bits > 16)
		return NULL;

	int length = (1 << nr_bits) + sizeof(unsigned int);

	hash_table_t * new_table = calloc(length, sizeof(void *));
	if (new_table == NULL)
		return NULL;

	new_table->bits = nr_bits;
	new_table->count = 0;
	return new_table;

}

/**
 * Find element in hash table
 * @param table pointer to hash table
 * @param hash 32-bit hash of object name
 */
void * hash_table_search(hash_table_t * table, uint32_t hash) {

	if (table == NULL)
		return NULL;

	if (table->bits > 16)
		return NULL;

	unsigned int key = hash >> (32 - table->bits);

	//printf("Hash is %"PRIx32", key is %x, element %p\r\n", hash, key, table->table[key]);

	/* Take the first element in the list */
	hash_list_t * element = table->table[key];

	/* If element does not exist, return */
	if (element == NULL)
		return NULL;

	/* If element is wanted item, return */
	if (element->hash == hash)
		return element;

	/* Else search in linked list */
	while (element->next_item != NULL) {
		element = element->next_item;
		if (element->hash == hash)
			return element;
	}

	/* Otherwise, just return NULL */
	return NULL;

}

/**
 * Insert into hash table
 * @param table hash table handle
 * @param hash 32 bit hash of element
 * @param element pointer to element, must be of type hash_list_t, or else...
 * @return -1 if err, 0 if ok
 */
int hash_table_insert(hash_table_t * table, uint32_t hash, hash_list_t * element) {

	hash_list_t * current_element;

	if (table == NULL)
		return -1;

	if (table->bits > 16)
		return -1;

	unsigned int key = hash >> (32 - table->bits);

	/* Ensure element has NULL next item, and store hash for fast search */
	table->count++;
	element->next_item = NULL;
	element->hash = hash;

	if (table->table[key] == NULL) {

		/* Insert as first element */
		table->table[key] = element;
		//printf("Inserted %p as head of index %x\r\n", element, key);

	} else {

		/* Find last element */
		current_element = table->table[key];
		while (current_element->next_item != NULL)
			current_element = current_element->next_item;
		current_element->next_item = element;
		//printf("Inserted %p after %p\r\n", element, current_element);

	}

	return 0;

}

/**
 * Return hash table count
 * @param table pointer to table
 * @return count of elements in table
 */
int hash_table_get_count(hash_table_t * table) {

	if (table == NULL)
		return -1;

	return table->count;

}

/**
 * Fill a list with hash_list_t types from a hash table,
 * this is useful for looping though all elements in table.
 * @param table pointer to table
 * @param list double pointer to preallocated list must be > hash_list_t* * length
 * @param length max size of allocated buffer. Use hash_table_get_count.
 * @return -1 if error, length otherwise.
 */
int hash_table_fill_element_list(hash_table_t * table, hash_list_t ** list, unsigned int length) {

	assert(table != NULL);
	assert(table->bits <= 16);

	unsigned int count = table->count;
	unsigned int i, j = 0;
	hash_list_t * current_element;

	/* Check if elements will fit in list */
	if (count > length)
		return -1;

	/* Loop all bins */
	for (i = 0; i < ((unsigned) 1 << table->bits); i++) {

		/* Get head element */
		if (table->table[i] != NULL) {

			current_element = table->table[i];
			list[j++] = current_element;

			while(current_element->next_item != NULL) {
				current_element = table->table[i]->next_item;
				list[j++] = current_element;
			}

		}

	}

	return j;

}

int hash_table_iterate(hash_table_t * table, hash_iter_func_t apply) {

	assert(table != NULL);

	unsigned int i, j = 0;
	hash_list_t * current_element;

	/* Loop all bins */
	for (i = 0; i < ((unsigned) 1 << table->bits); i++) {

		/* Get head element */
		if (table->table[i] != NULL) {

			current_element = table->table[i];
			apply(j++, current_element);

			while(current_element->next_item != NULL) {
				current_element = table->table[i]->next_item;
				apply(j++, current_element);
			}

		}

	}

	return 0;

}
